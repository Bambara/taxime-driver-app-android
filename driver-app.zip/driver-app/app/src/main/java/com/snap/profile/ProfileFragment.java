package com.snap.profile;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.core.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.snap.R;
import com.snap.other.VehicleSelecterPopup;
import com.snap.session.LoginSession;

public class ProfileFragment extends Fragment {
    private TextView name, birthDay, email, mobileNumber, address;
    private Button vehicleInfoButton, logoutButton;
    private ImageView profileImage;

    public static ProfileFragment newInstance() {
        ProfileFragment fragment = new ProfileFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @SuppressLint("ResourceAsColor")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View myFragmentView =  inflater.inflate(R.layout.fragment_profile, container, false);

        /**
         * set status bar colour
         */
        Window window = this.getActivity().getWindow();   // clear FLAG_TRANSLUCENT_STATUS flag:
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);  // add FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS flag to the window
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);   // finally change the color
        window.setStatusBarColor(ContextCompat.getColor(getContext(), R.color.ashOne));

        myFragmentView.findViewById(R.id.image_upload_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), ImageUpdateActivity.class);
                startActivity(intent);
            }
        });

        name = myFragmentView.findViewById(R.id.driver_name);
        birthDay = myFragmentView.findViewById(R.id.birthday);
        email = myFragmentView.findViewById(R.id.passenger_name);
        mobileNumber = myFragmentView.findViewById(R.id.mobile_number);
        address = myFragmentView.findViewById(R.id.address);
        vehicleInfoButton = myFragmentView.findViewById(R.id.vehicle_info_button);
        profileImage = myFragmentView.findViewById(R.id.profile_image);

        LoginSession session = new LoginSession(getContext());
        name.setText(session.getUserDetails().getContent().getFirstName() + " " + session.getUserDetails().getContent().getLastName());
        birthDay.setText(session.getUserDetails().getContent().getBirthday().substring(0, 10));
        email.setText(session.getUserDetails().getContent().getEmail());
        mobileNumber.setText(session.getUserDetails().getContent().getContactNo());
        address.setText(session.getUserDetails().getContent().getAddress().getAddress());

        Glide.with(getContext()).load(new LoginSession(getContext()).getUserDetails().getContent().getProfileImage()).into(profileImage);

        vehicleInfoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new VehicleSelecterPopup(getContext(), getActivity());
            }
        });

        logoutButton = myFragmentView.findViewById(R.id.logout_button);
        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new LoginSession(getContext()).logoutUser();
            }
        });

        return myFragmentView;
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onStart() {
        super.onStart();
    }

    @Override
    public void onStop() {
        super.onStop();
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
    }
    @Override
    public void onDestroyView() {
//        //Fragment fragment = getFragmentManager().findFragmentById(R.id.fragment);
//        //if (fragment != null) {
//            getFragmentManager().beginTransaction().remove(ProfileFragment.newInstance()).commit();
//        //}
        super.onDestroyView();
    }

}
