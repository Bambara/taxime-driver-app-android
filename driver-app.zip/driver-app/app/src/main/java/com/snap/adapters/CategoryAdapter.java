package com.snap.adapters;

import android.content.Context;

import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.snap.R;
import com.snap.config.KeyString;
import com.snap.model.vehicalCategoryModel.VehicleCategoryResponseModel;

import java.util.List;

public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.MyViewHolder> {
    private List<VehicleCategoryResponseModel.Content> categories;
    static Context context;
    private static int unitCost, selected = 0;
    private static SingleClickListener clickListener;

    public CategoryAdapter(Context context, VehicleCategoryResponseModel categories, int selected) {
        this.context = context;
        this.categories = categories.getContent();
        this.selected = selected;
        this.unitCost = categories.getUnitCost();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        ImageView subcategoryImage;
        TextView subcategoryName;

        public MyViewHolder(View itemView) {
            super(itemView);
            this.subcategoryImage = itemView.findViewById(R.id.subcategory_image);
            this.subcategoryName = itemView.findViewById(R.id.subcategory_name);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            selected = getAdapterPosition();
            clickListener.onItemClickListener(getAdapterPosition(), categories);
        }

    }

    public void selectedItem(int unitCost) {
        this.unitCost = unitCost;
        notifyDataSetChanged();
    }

    public void categoryChange(int position) {
        this.selected = position;
        notifyDataSetChanged();
    }

    public void categoryEnable(int unitCost) {
        this.unitCost = unitCost;
        notifyDataSetChanged();
    }

    public void setOnItemClickListener(SingleClickListener clickListener) {
        this.clickListener = clickListener;
    }

    @Override
    public CategoryAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.category_recyclerview_item, parent, false);
        return new CategoryAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final CategoryAdapter.MyViewHolder holder, final int position) {

        if (selected == position ) {
            Glide.with(context).load(KeyString.BASE_URL + categories.get(position).getSubCategoryIconSelected()).into(holder.subcategoryImage);
            //holder.subcategoryImage.getLayoutParams().height = dpToPx(78);
            holder.subcategoryName.setText(categories.get(position).getSubCategoryName());
            //holder.subcategoryImage.setImageBitmap(categoryIconSelected.get(position));
            holder.subcategoryImage.setColorFilter(null);
        } else {
            Glide.with(context).load(KeyString.BASE_URL + categories.get(position).getSubCategoryIcon()).into(holder.subcategoryImage);
            //holder.subcategoryImage.getLayoutParams().height = dpToPx(78);
            holder.subcategoryName.setText(categories.get(position).getSubCategoryName());
            //holder.subcategoryImage.setImageBitmap(categoryIcon.get(position));
            if (unitCost >= categories.get(position).getLowerBidLimit()) {
                holder.subcategoryImage.setColorFilter(null);
            } else {
                holder.subcategoryImage.setColorFilter(context.getResources().getColor(R.color.ashTwo));
            }
        }

    }

    @Override
    public int getItemCount() {
        return categories.size();
    }

    public interface SingleClickListener {
        void onItemClickListener(int position, List<VehicleCategoryResponseModel.Content> categories);
    }

    public static int dpToPx(int dp) {
        float density = context.getResources().getDisplayMetrics().density;
        return Math.round((float) dp * density);
    }
}
