package com.snap.home.driver;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.gson.Gson;
import com.snap.R;
import com.snap.config.KeyString;
import com.snap.gps.GPSTracker;
import com.snap.model.DispatchTripEndRequestModel;
import com.snap.model.Location;
import com.snap.model.PassengerTripEndRequestModel;
import com.snap.model.tripAcceptModel.TripAcceptResponseModel;
import com.snap.model.tripModel.TripModel;
import com.snap.rest.ApiInterface;
import com.snap.rest.JsonApiClient;
import com.snap.session.LoginSession;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class TripBillingActivity extends AppCompatActivity {
    private TextView totalFare, date, discount, fare, distance, tripTime, waitTime, waitCost, cancelFee;
    private Button paymentButton;
    private TripModel tripModel;
    private TripAcceptResponseModel tripPriceModel;
    private double waitTimeMillis = 0.0, totalTimeMillis = 0.0, totalDistance = 0.0;
    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trip_billing);

        Bundle bundle = getIntent().getExtras();
        String json = bundle.getString(KeyString.TRIP_MODEL);
        String json1 = bundle.getString(KeyString.TRIP_PRICE_MODEL);
        waitTimeMillis = bundle.getDouble(KeyString.WAIT_TIME);
        totalTimeMillis = bundle.getDouble(KeyString.TOTAL_TIME);
        totalDistance = bundle.getDouble(KeyString.DISTANCE);
        Gson gson = new Gson();
        tripModel = gson.fromJson(json, TripModel.class);
        tripPriceModel = gson.fromJson(json1, TripAcceptResponseModel.class);

        totalFare = findViewById(R.id.total_fare);
        date = findViewById(R.id.date);
        discount = findViewById(R.id.discount);
        fare = findViewById(R.id.fare);
        distance = findViewById(R.id.distance);
        tripTime = findViewById(R.id.trip_time);
        waitTime = findViewById(R.id.wait_time);
        waitCost = findViewById(R.id.wait_cost);
        cancelFee = findViewById(R.id.cancel_fee);
        paymentButton = findViewById(R.id.payment_button);

        priceCalculation();
    }

    /**
     * hire cost calculation and set thees value in UI
     * @return
     */
    private double priceCalculation() {
        double tripDistance, waitCost = 0.0, tripFare = 0.0, totalFare = 0.0;
        if (Math.abs((tripModel.getDistance() * 1000) - totalDistance) > 1000) {
            tripDistance = totalDistance/1000;
        } else {
            tripDistance = tripModel.getDistance();
        }
        if ((waitTimeMillis/60000) > 5) {
            waitCost = ((waitTimeMillis/60000) - 5) * tripPriceModel.getContent().get(0).getNormalWaitingChargePerMinute();
        }
        if (tripDistance <= tripPriceModel.getContent().get(0).getMinimumKM()) {
            tripFare = tripPriceModel.getContent().get(0).getBaseFare() + tripPriceModel.getContent().get(0).getMinimumFare();
            totalFare = tripFare + waitCost;
        } else if (tripDistance <= tripPriceModel.getContent().get(0).getBelowAboveKMRange()) {
            tripFare = tripPriceModel.getContent().get(0).getBaseFare() + tripPriceModel.getContent().get(0).getMinimumFare()
                    + (tripDistance - tripPriceModel.getContent().get(0).getMinimumKM()) * tripModel.getBidValue();
            totalFare = tripFare + waitCost;
        } else if (tripDistance > tripPriceModel.getContent().get(0).getBelowAboveKMRange()) {
            tripFare = tripPriceModel.getContent().get(0).getBaseFare() + tripPriceModel.getContent().get(0).getMinimumFare()
                    + (tripPriceModel.getContent().get(0).getBelowAboveKMRange() - tripPriceModel.getContent().get(0).getMinimumKM()) * tripModel.getBidValue()
                    + (tripDistance - tripPriceModel.getContent().get(0).getBelowAboveKMRange()) * tripPriceModel.getContent().get(0).getAboveKMFare();
            totalFare = tripFare + waitCost;
        }
        this.totalFare.setText(String.valueOf(round(totalFare, 2)) + " " + getResources().getString(R.string.rs));
        date.setText(tripModel.getPickupDateTime().substring(0, 10));
        discount.setText(getResources().getString(R.string.no_discount));
        fare.setText(String.valueOf(round(tripFare, 2)) + " " + getResources().getString(R.string.rs));
        distance.setText(String.valueOf(round(tripDistance, 1)) + " " + getResources().getString(R.string.km));
        tripTime.setText(String.valueOf((int)(totalTimeMillis/60000)) + " " + getResources().getString(R.string.min));
        waitTime.setText(String.valueOf((int)(waitTimeMillis/60000)) + " " + getResources().getString(R.string.min));
        this.waitCost.setText(String.valueOf(round(waitCost, 2)) + " " + getResources().getString(R.string.rs));

        final DispatchTripEndRequestModel dDataModel = new DispatchTripEndRequestModel();
        final PassengerTripEndRequestModel pDataModel = new PassengerTripEndRequestModel();
        if (tripModel.getType().equals(KeyString.ADMIN_DISPATCH) || tripModel.getType().equals(KeyString.USER_DISPATCH) || tripModel.getType().equals(KeyString.DRIVER_DISPATCH)) {
            dDataModel.setDispatchId(tripModel.getId());
            dDataModel.setType(tripModel.getType());
            dDataModel.setDistance(tripDistance);
            dDataModel.setWaitingCost(waitCost);
            dDataModel.setWaitTime((int)(waitTimeMillis/60000));
            dDataModel.setEstimatedCost(tripModel.getHireCost());
            dDataModel.setTotalCost(totalFare);
            dDataModel.setDispatcherId(tripModel.getDispatcherId());
            dDataModel.setAdminCommission(tripPriceModel.getContent().get(0).getDistrictPrice());
            dDataModel.setDriverId(new LoginSession(getApplicationContext()).getUserDetails().getContent().getId());
            dDataModel.setPaymentMethod("cash");
            dDataModel.setRealPickupLocation(tripModel.getPickupLocation());

            GPSTracker location = new GPSTracker(getApplicationContext());
            Location realDropLocation = new Location();
            realDropLocation.setLatitude(location.getLatitude());
            realDropLocation.setLongitude(location.getLongitude());
            realDropLocation.setAddress(location.getAddressLine(getApplicationContext()));

            dDataModel.setRealDropLocation(realDropLocation);
            dDataModel.setDestinations(tripModel.getDropLocations());
            dDataModel.setTripTime(String.valueOf(totalTimeMillis/60000));
        } else if (tripModel.getType().equals(KeyString.PASSENGER_TRIP)) {
            pDataModel.setTripId(tripModel.getId());
            pDataModel.setPassengerId(tripModel.getPassengerDetails().getId());
            pDataModel.setAdminCommission(tripPriceModel.getContent().get(0).getDistrictPrice());
            pDataModel.setDriverId(new LoginSession(getApplicationContext()).getUserDetails().getContent().getId());
            pDataModel.setPaymentMethod("cash");
            pDataModel.setType(tripModel.getType());
            pDataModel.setDistance(tripDistance);
            pDataModel.setWaitingCost(waitCost);
            pDataModel.setWaitTime((int)(waitTimeMillis/60000));
            pDataModel.setEstimatedCost(tripModel.getHireCost());
            pDataModel.setTotalCost(totalFare);
            pDataModel.setRealPickupLocation(tripModel.getPickupLocation());

            GPSTracker location = new GPSTracker(getApplicationContext());
            Location realDropLocation = new Location();
            realDropLocation.setAddress(location.getAddressLine(getApplicationContext()));
            realDropLocation.setLatitude(location.getLatitude());
            realDropLocation.setLongitude(location.getLongitude());

            pDataModel.setRealDropLocation(realDropLocation);
            pDataModel.setDestinations(tripModel.getDropLocations());
            pDataModel.setTripTime(String.valueOf(totalTimeMillis/60000));
        }

        paymentButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (tripModel.getType().equals(KeyString.ADMIN_DISPATCH) || tripModel.getType().equals(KeyString.USER_DISPATCH) || tripModel.getType().equals(KeyString.DRIVER_DISPATCH)) {
                    dispatchTripEnd(dDataModel);
                } else if (tripModel.getType().equals(KeyString.PASSENGER_TRIP)) {
                    passengerTripEnd(pDataModel);
                } else  {
                    AlertDialog alertDialog = new AlertDialog.Builder(TripBillingActivity.this).create();
                    alertDialog.setTitle("ERROR");
                    alertDialog.setMessage("trip type does not match");
                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.show();
                }
            }
        });

        return totalFare;
    }

    /**
     * calculate distance between two geo location
     * @param prevLatitude
     * @param preLongitude
     * @param newLatitude
     * @param newLongitude
     * @return
     */
    private Double getDistance(double prevLatitude, double preLongitude, double newLatitude, double newLongitude) {
        android.location.Location loc1 = new android.location.Location("");
        loc1.setLatitude(prevLatitude);
        loc1.setLongitude(preLongitude);
        android.location.Location loc2 = new android.location.Location("");
        loc2.setLatitude(newLatitude);
        loc2.setLongitude(newLongitude);
        double distanceInMeters = loc1.distanceTo(loc2);
        return Math.abs(distanceInMeters);
    }

    /**
     * round double value with two floating point
     * @param value
     * @param places
     * @return
     */
    public double round(double value, int places) {
        if (places < 0) throw new IllegalArgumentException();

        long factor = (long) Math.pow(10, places);
        value = value * factor;
        long tmp = Math.round(value);
        return (double) tmp / factor;
    }

    /**
     * dispatch trip end API call
     * @param model
     */
    private void dispatchTripEnd(DispatchTripEndRequestModel model) {
        progressDialog = new ProgressDialog(TripBillingActivity.this);
        progressDialog.setMessage("Loading...");
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();
        ApiInterface apiInterface = JsonApiClient.getApiClient().create(ApiInterface.class);
        Call<ResponseBody> call = apiInterface.endDispatchTrip(model);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                progressDialog.dismiss();
                Log.i("TAG CHECK DRIVER CODE", String.valueOf(response.code()));
                if (response.code() == 200) {
                    finish();
                } else {
                    AlertDialog alertDialog = new AlertDialog.Builder(TripBillingActivity.this).create();
                    alertDialog.setTitle("Something Went Wrong");
                    alertDialog.setMessage("please try again");
                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.show();
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                progressDialog.dismiss();
                Log.i("TAG CHECK DRIVER FAIL", t.getMessage());
                AlertDialog alertDialog = new AlertDialog.Builder(TripBillingActivity.this).create();
                alertDialog.setTitle("Something Went Wrong");
                alertDialog.setMessage("please try again");
                alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                alertDialog.show();
            }
        });
    }

    /**
     * passenger trip end api call
     * @param model
     */
    private void passengerTripEnd(PassengerTripEndRequestModel model) {
        progressDialog = new ProgressDialog(TripBillingActivity.this);
        progressDialog.setMessage("Loading...");
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();
        ApiInterface apiInterface = JsonApiClient.getApiClient().create(ApiInterface.class);
        Call<ResponseBody> call = apiInterface.endPassengerTrip(model);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                progressDialog.dismiss();
                Log.i("TAG CHECK DRIVER CODE", String.valueOf(response.code()));
                if (response.code() == 200) {
                    finish();
                } else {
                    AlertDialog alertDialog = new AlertDialog.Builder(TripBillingActivity.this).create();
                    alertDialog.setTitle("Something Went Wrong");
                    alertDialog.setMessage("please try again \ncode : " + String.valueOf(response.code()));
                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.show();
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                progressDialog.dismiss();
                Log.i("TAG CHECK DRIVER FAIL", t.getMessage());
                AlertDialog alertDialog = new AlertDialog.Builder(TripBillingActivity.this).create();
                alertDialog.setTitle("Something Went Wrong");
                alertDialog.setMessage("please try again");
                alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                alertDialog.show();
            }
        });
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
    }
}
