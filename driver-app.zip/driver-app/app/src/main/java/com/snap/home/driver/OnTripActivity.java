package com.snap.home.driver;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Handler;
import android.os.PowerManager;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.github.nkzawa.emitter.Emitter;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.gson.Gson;
import com.snap.R;
import com.snap.background.LocationMonitoringService;
import com.snap.config.KeyString;
import com.snap.config.Permission;
import com.snap.gps.GPSTracker;
import com.snap.model.tripCancelModel.DispatchTripCancelRequestModel;
import com.snap.model.DriverState;
import com.snap.model.Location;
import com.snap.model.tripAcceptModel.TripAcceptResponseModel;
import com.snap.model.tripCancelModel.PassengerTripCancelRequestModel;
import com.snap.model.tripModel.TripModel;
import com.snap.rest.ApiInterface;
import com.snap.rest.JsonApiClient;
import com.snap.session.LoginSession;
import com.snap.session.TripSession;
import com.snap.socket.MySocket;

import org.json.JSONException;
import org.json.JSONObject;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class OnTripActivity extends AppCompatActivity implements OnMapReadyCallback {
    TripSession tripSession;
    private static final String MAP_VIEW_BUNDLE_KEY = "MapViewBundleKey";
    private GoogleMap gmap;
    private MapView mapView;
    private GPSTracker location;
    LatLng latLng;
    private ImageView crossButton, callButton, smsButton;
    private ConstraintLayout tripInfo, tripInfoButton, navigateButton;
    private TripModel tripModel;
    private TripAcceptResponseModel tripPriceModel;
    private TextView name, date, cost, distance, passengers;
    private Button button, cancelButton;
    protected PowerManager.WakeLock mWakeLock;
    private com.github.nkzawa.socketio.client.Socket mSocket;
    private double lastLongitude, lastLatitude, waitTimeMillis = 0.0, totalTimeMillis = 0.0, waitedDistance = 0.0;
    private Runnable distanceTimer;
    private Handler handler = new Handler();
    double totalDistance = 0.0, prevDistance = 0.0;
    ProgressDialog progressDialog;
    private double latitude, longitude;
    private String address;
    private boolean checker = false;

    @SuppressLint("InvalidWakeLockTag")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_on_trip);

        /* This code together with the one in onDestroy()
         * will make the screen be always on until this Activity gets destroyed. */
        final PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        this.mWakeLock = pm.newWakeLock(PowerManager.SCREEN_DIM_WAKE_LOCK, "My Tag");
        this.mWakeLock.acquire();

        /**
         * set status bar colour
         */
        Window window = getWindow();   // clear FLAG_TRANSLUCENT_STATUS flag:
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);  // add FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS flag to the window
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);   // finally change the color
        window.setStatusBarColor(ContextCompat.getColor(getApplicationContext(), R.color.transparentAsh));

        location = new GPSTracker(getApplicationContext());
        latitude = location.getLatitude();
        longitude = location.getLongitude();
        address = location.getAddressLine(getApplicationContext());

        LocalBroadcastManager.getInstance(OnTripActivity.this).registerReceiver(
                new BroadcastReceiver() {
                    @Override
                    public void onReceive(Context context, Intent intent) {
                        latitude = intent.getDoubleExtra(KeyString.EXTRA_LATITUDE, 0);
                        longitude = intent.getDoubleExtra(KeyString.EXTRA_LONGITUDE, 0);
                        address = intent.getStringExtra(KeyString.EXTRA_ADDRESS);
                    }
                }, new IntentFilter(LocationMonitoringService.ACTION_LOCATION_BROADCAST)
        );

        tripSession = new TripSession(getApplicationContext());

        MySocket socket = (MySocket)getApplication();
        mSocket = socket.getmSocket();

        button = findViewById(R.id.button);
        button.setVisibility(View.VISIBLE);
        cancelButton = findViewById(R.id.cancel_button);
        tripInfo = findViewById(R.id.trip_info);
        tripInfo.setVisibility(View.GONE);
        tripInfoButton = findViewById(R.id.trip_info_button);


       if (!tripSession.isTrip()) {
           Bundle bundle = getIntent().getExtras();
           String json = bundle.getString(KeyString.TRIP_MODEL);
           String json1 = bundle.getString(KeyString.TRIP_PRICE_MODEL);
           Gson gson = new Gson();
           tripModel = gson.fromJson(json, TripModel.class);
           tripPriceModel = gson.fromJson(json1, TripAcceptResponseModel.class);

           LoginSession session = new LoginSession(getApplicationContext());
           session.setDriverState(KeyString.GOING_TO_PICKUP);
           DriverState state = new DriverState(mSocket.id(), session.getDriverState(), new LoginSession(getApplicationContext()).get_Id());
//        boolean checker = true;
//        while (checker) {
//            if (mSocket.connected()) {
//                try {
//                    mSocket.emit(KeyString.UPDATE_DRIVER_STATE_SOCKET, new JSONObject(new Gson().toJson(state, DriverState.class)));
//                } catch (JSONException e) {
//                    e.printStackTrace();
//                }
//                checker = false;
//            }
//        }
           try {
               mSocket.emit(KeyString.UPDATE_DRIVER_STATE_SOCKET, new JSONObject(new Gson().toJson(state, DriverState.class)));
           } catch (JSONException e) {
               e.printStackTrace();
           }



       } else {
           tripModel = tripSession.getTripModel();
           tripPriceModel = tripSession.getTripPriceModel();
           lastLongitude = tripSession.getLastLongitude();
           lastLatitude = tripSession.getLastLatitude();
           waitTimeMillis = tripSession.getWaitTimeMillis();
           totalTimeMillis = tripSession.getTotalTimeMillis();
           totalDistance = tripSession.getTotalDistance();
           prevDistance = tripSession.getPrevDistance();

           DriverState state = new DriverState(mSocket.id(), tripSession.getDriverState(), new LoginSession(getApplicationContext()).get_Id());
           new LoginSession(getApplicationContext()).setDriverState(tripSession.getDriverState());
            boolean checker = true;
            while (checker) {
                if (mSocket.connected()) {
                    try {
                        mSocket.emit(KeyString.UPDATE_DRIVER_STATE_SOCKET, new JSONObject(new Gson().toJson(state, DriverState.class)));
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    checker = false;
                }
            }

           if (tripSession.getDriverState().equals(KeyString.GOING_TO_PICKUP)) {
                button.setText(getResources().getString(R.string.start));
               button.setBackground(getResources().getDrawable(R.drawable.blue_view_background_with_redious_conner));
           } else {
               button.setText(getResources().getString(R.string.end));
               button.setBackground(getResources().getDrawable(R.drawable.red_view_background_with_redious_conner));
               cancelButton.setVisibility(View.GONE);
               setTimer(tripSession.getLastLatitude(), tripSession.getLastLongitude());
           }
           button.setVisibility(View.GONE);
       }
        if (tripModel == null) return;
        setData(tripModel);


        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (tripModel.getType().equals(KeyString.PASSENGER_TRIP)) {
                    cancelPassengerTrip();
                } else {
                    cancelDispatchTrip();
                }
            }
        });


        latLng = new LatLng(location.getLatitude(), location.getLongitude());
        Bundle mapViewBundle = null;
        if (savedInstanceState != null) {
            mapViewBundle = savedInstanceState.getBundle(MAP_VIEW_BUNDLE_KEY);
        }
        mapView = findViewById(R.id.map_view);
        mapView.onCreate(mapViewBundle);
        mapView.getMapAsync(this);

        tripInfoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (tripInfo.getVisibility() != View.VISIBLE) {
                    tripInfo.setVisibility(View.VISIBLE);
                    button.setVisibility(View.GONE);
                } else {
                    tripInfo.setVisibility(View.GONE);
                    button.setVisibility(View.VISIBLE);
                }
            }
        });

        navigateButton = findViewById(R.id.navigate_button);
        navigateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (new LoginSession(getApplicationContext()).getDriverState().equals(KeyString.GOING_TO_PICKUP)) {
                    Uri gmmIntentUri = Uri.parse("google.navigation:q=" + tripModel.getPickupLocation().getLatitude() + "," + tripModel.getPickupLocation().getLongitude());
                    Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                    mapIntent.setPackage("com.google.android.apps.maps");
                    startActivity(mapIntent);
                } else {
                    Uri gmmIntentUri = Uri.parse("google.navigation:q=" + tripModel.getDropLocations().get(0).getLatitude() + "," + tripModel.getDropLocations().get(0).getLongitude());
                    Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                    mapIntent.setPackage("com.google.android.apps.maps");
                    startActivity(mapIntent);
                }
            }
        });

        crossButton = findViewById(R.id.cross_image);
        crossButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tripInfo.setVisibility(View.GONE);
                button.setVisibility(View.VISIBLE);
            }
        });


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (button.getText().toString().equals(getResources().getString(R.string.arrived))) {
                    button.setBackground(getResources().getDrawable(R.drawable.blue_view_background_with_redious_conner));
                    button.setText(getResources().getString(R.string.start));
                } else if (button.getText().toString().equals(getResources().getString(R.string.start))) {
                    final AlertDialog alertDialog = new AlertDialog.Builder(OnTripActivity.this).create();
                    LayoutInflater inflater = getLayoutInflater();
                    View view = inflater.inflate(R.layout.trip_start_dialog, null, false);
                    view.findViewById(R.id.confirm_button).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            alertDialog.dismiss();
                            button.setBackground(getResources().getDrawable(R.drawable.red_view_background_with_redious_conner));
                            button.setText(getResources().getString(R.string.end));
                            cancelButton.setVisibility(View.GONE);
                            GPSTracker location = new GPSTracker(getApplicationContext());
                            Location realPickupLocation = new Location();
                            realPickupLocation.setLatitude(location.getLatitude());
                            realPickupLocation.setLongitude(location.getLongitude());
                            realPickupLocation.setAddress(location.getAddressLine(getApplicationContext()));
                            tripModel.setPickupLocation(realPickupLocation);
                            new LoginSession(getApplicationContext()).setDriverState(KeyString.ON_TRIP);
                            setTimer(latitude, longitude);
                        }
                    });
                    view.findViewById(R.id.cancel_button).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            alertDialog.dismiss();
                        }
                    });
                    alertDialog.setView(view);
                    alertDialog.setCanceledOnTouchOutside(false);
                    alertDialog.show();
                } else if (button.getText().toString().equals(getResources().getString(R.string.end))) {
                    final AlertDialog alertDialog = new AlertDialog.Builder(OnTripActivity.this).create();
                    LayoutInflater inflater = getLayoutInflater();
                    View view = inflater.inflate(R.layout.trip_end_dialog, null, false);
                    view.findViewById(R.id.confirm_button).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            alertDialog.dismiss();
                            new LoginSession(getApplicationContext()).setDriverState(KeyString.ONLINE);
                            handler.removeCallbacks(distanceTimer);
                            Intent intent = new Intent(getApplicationContext(), TripBillingActivity.class);
                            intent.putExtra(KeyString.TRIP_MODEL, new Gson().toJson(tripModel));
                            intent.putExtra(KeyString.TRIP_PRICE_MODEL, new Gson().toJson(tripPriceModel));
                            intent.putExtra(KeyString.TOTAL_TIME, totalTimeMillis);
                            intent.putExtra(KeyString.WAIT_TIME, waitTimeMillis);
                            intent.putExtra(KeyString.DISTANCE, waitedDistance);
                            startActivity(intent);
                            finish();
                        }
                    });
                    view.findViewById(R.id.cancel_button).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            alertDialog.dismiss();
                        }
                    });
                    alertDialog.setView(view);
                    alertDialog.setCanceledOnTouchOutside(false);
                    alertDialog.show();
                }
                DriverState state = new DriverState(mSocket.id(), new LoginSession(getApplicationContext()).getDriverState(), new LoginSession(getApplicationContext()).get_Id());
//                boolean checker = true;
//                while (checker) {
//                    if (mSocket.connected()) {
//                        try {
//                            mSocket.emit(KeyString.UPDATE_DRIVER_STATE_SOCKET, new JSONObject(new Gson().toJson(state, DriverState.class)));
//                        } catch (JSONException e) {
//                            e.printStackTrace();
//                        }
//                        checker = false;
//                    }
//                }
                try {
                    mSocket.emit(KeyString.UPDATE_DRIVER_STATE_SOCKET, new JSONObject(new Gson().toJson(state, DriverState.class)));
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });

        callButton = findViewById(R.id.call_button);
        callButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_CALL);
                if (tripModel.getType().equals(KeyString.PASSENGER_TRIP)) {
                    intent.setData(Uri.parse("tel:" + tripModel.getPassengerDetails().getContactNumber()));
                } else {
                    intent.setData(Uri.parse("tel:" + tripModel.getMobileNumber()));
                }
                if (ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    new Permission(getApplicationContext(), OnTripActivity.this).checkPermissions();
                    return;
                }
                startActivity(intent);
            }
        });

        tripCancelListner();
    }

    /**
     * listener for trip cancel by passenger
     */
    private void tripCancelListner() {
        mSocket.on(KeyString.PASSENGER_CANCEL_TRIP_SOCKET, new Emitter.Listener() {

            @Override
            public void call(Object... args) {
                if (checker == false) {
                    checker = true;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            AlertDialog alertDialog = new AlertDialog.Builder(OnTripActivity.this).create();
                            alertDialog.setTitle(getResources().getString(R.string.cancel_trip));
                            alertDialog.setMessage(getResources().getString(R.string.trip_cancel_by_passenger));
                            alertDialog.setCanceledOnTouchOutside(false);
                            alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();
                                        new LoginSession(getApplicationContext()).setDriverState(KeyString.ONLINE);
                                        DriverState state = new DriverState(mSocket.id(), new LoginSession(getApplicationContext()).getDriverState(), new LoginSession(getApplicationContext()).get_Id());
                                        boolean checker = true;
                                        while (checker) {
                                            if (mSocket.connected()) {
                                                try {
                                                    mSocket.emit(KeyString.UPDATE_DRIVER_STATE_SOCKET, new JSONObject(new Gson().toJson(state, DriverState.class)));
                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                }
                                                checker = false;
                                            }
                                        }
                                        //onBackPressed();
                                        finish();
                                    }
                                });
                            if (!OnTripActivity.this.isFinishing()) {
                                alertDialog.show();
                            }
                        }
                    });
                }
            }
        });
    }

    /**
     * trip info UI data attachment method
     * @param model
     */
    private void setData(TripModel model) {
        name = findViewById(R.id.name);
        cost = findViewById(R.id.cost);
        date = findViewById(R.id.time);
        passengers = findViewById(R.id.passengers);
        distance = findViewById(R.id.distance);

        name.setText(model.getCustomerName());
        cost.setText("Rs " + String.valueOf(round(model.getHireCost(), 2)));
        date.setText(model.getPickupDateTime().substring(0,10));
        passengers.setText(String.valueOf(model.getNoOfPassengers()) + " " + getResources().getString(R.string.passengers));
        distance.setText(String.valueOf(model.getDistance()) + " km");
    }

    /**
     * round double value with two floating point
     * @param value
     * @param places
     * @return
     */
    public double round(double value, int places) {
        if (places < 0) throw new IllegalArgumentException();

        long factor = (long) Math.pow(10, places);
        value = value * factor;
        long tmp = Math.round(value);
        return (double) tmp / factor;
    }


    /**
     * method for calculate waiting time and distance
     * @param pickupLongitude
     * @param pickupLatitude
     */
    private void setTimer(final double pickupLatitude, final double pickupLongitude) {
        lastLongitude = pickupLongitude;
        lastLatitude = pickupLatitude;
        distanceTimer = new Runnable() {
            @Override
            public void run() {
//                GPSTracker location = new GPSTracker(getApplicationContext());
                totalTimeMillis = totalTimeMillis + 1000;

                if (getDistance(lastLatitude, lastLongitude, latitude, longitude) < 0.01) {
                    waitTimeMillis = waitTimeMillis + 1000;
                }

                if (getDistance(lastLatitude, lastLongitude, latitude, longitude) < 10000) {
                    totalDistance = prevDistance + getDistance(lastLatitude, lastLongitude, latitude, longitude);
                    waitedDistance = totalDistance + totalDistance * 0.012;
                    lastLatitude = latitude;
                    lastLongitude = longitude;
                    prevDistance = totalDistance;
                }

                handler.postDelayed(this, 1000);
            }
        };
        handler.postDelayed(distanceTimer, 1000);
    }

    /**
     * passenger trip cancellation method
     */
    private void cancelPassengerTrip() {
        progressDialog = new ProgressDialog(OnTripActivity.this);
        progressDialog.setMessage("Loading...");
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();

        PassengerTripCancelRequestModel dataModel = new PassengerTripCancelRequestModel();
        dataModel.setCancelCost(tripPriceModel.getContent().get(0).getTripCancelationFee());
        dataModel.setType(tripModel.getType());
        dataModel.setCancelReason(" ");
        dataModel.setDriverId(new LoginSession(getApplicationContext()).getUserDetails().getContent().getId());
        dataModel.setTripId(tripModel.getId());
        dataModel.setPickupLocation(tripModel.getPickupLocation());
        dataModel.setDropLocations(tripModel.getDropLocations());
        dataModel.setPassengerId(tripModel.getPassengerDetails().getId());
        dataModel.setEstimatedCost(tripModel.getHireCost());

        ApiInterface apiInterface = JsonApiClient.getApiClient().create(ApiInterface.class);
        Call<ResponseBody> call = apiInterface.cancelPassengerTrip(dataModel);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                progressDialog.dismiss();
                Log.i("TAG CHECK DRIVER CODE", String.valueOf(response.code()));
                if (response.code() == 200) {
                    new LoginSession(getApplicationContext()).setDriverState(KeyString.ONLINE);
                    DriverState state = new DriverState(mSocket.id(), new LoginSession(getApplicationContext()).getDriverState(), new LoginSession(getApplicationContext()).get_Id());
                    boolean checker = true;
                    while (checker) {
                        if (mSocket.connected()) {
                            try {
                                mSocket.emit(KeyString.UPDATE_DRIVER_STATE_SOCKET, new JSONObject(new Gson().toJson(state, DriverState.class)));
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                            checker = false;
                        }
                    }
                    //onBackPressed();
                    finish();
                } else {
                    AlertDialog alertDialog = new AlertDialog.Builder(OnTripActivity.this).create();
                    alertDialog.setTitle("Something Went Wrong");
                    alertDialog.setMessage("please try again");
                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.show();
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                progressDialog.dismiss();
                Log.i("TAG CHECK DRIVER FAIL", t.getMessage());
                AlertDialog alertDialog = new AlertDialog.Builder(OnTripActivity.this                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               ).create();
                alertDialog.setTitle("Something Went Wrong");
                alertDialog.setMessage("please try again");
                alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                alertDialog.show();
            }
        });
    }

    /**
     * dispatch trip cancellation method
     */
    private void cancelDispatchTrip() {
        progressDialog = new ProgressDialog(OnTripActivity.this);
        progressDialog.setMessage("Loading...");
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();

        DispatchTripCancelRequestModel dataModel = new DispatchTripCancelRequestModel();
        dataModel.setDiverId(new LoginSession(getApplicationContext()).getUserDetails().getContent().getId());
        dataModel.setVehicleId(new LoginSession(getApplicationContext()).getVehicle().getId());
        dataModel.setType(tripModel.getType());
        dataModel.setDispatchId(tripModel.getId());

        ApiInterface apiInterface = JsonApiClient.getApiClient().create(ApiInterface.class);
        Call<ResponseBody> call = apiInterface.cancelDispatchTrip(dataModel);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                progressDialog.dismiss();
                Log.i("TAG CHECK DRIVER CODE", String.valueOf(response.code()));
                if (response.code() == 200) {
                    new LoginSession(getApplicationContext()).setDriverState(KeyString.ONLINE);
                    DriverState state = new DriverState(mSocket.id(), new LoginSession(getApplicationContext()).getDriverState(), new LoginSession(getApplicationContext()).get_Id());
                    boolean checker = true;
                    while (checker) {
                        if (mSocket.connected()) {
                            try {
                                mSocket.emit(KeyString.UPDATE_DRIVER_STATE_SOCKET, new JSONObject(new Gson().toJson(state, DriverState.class)));
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                            checker = false;
                        }
                    }
                    //onBackPressed();
                    finish();
                } else {
                    AlertDialog alertDialog = new AlertDialog.Builder(OnTripActivity.this).create();
                    alertDialog.setTitle("Something Went Wrong");
                    alertDialog.setMessage("please try again");
                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.show();
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                progressDialog.dismiss();
                Log.i("TAG CHECK DRIVER FAIL", t.getMessage());
                AlertDialog alertDialog = new AlertDialog.Builder(OnTripActivity.this                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               ).create();
                alertDialog.setTitle("Something Went Wrong");
                alertDialog.setMessage("please try again");
                alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                alertDialog.show();
            }
        });
    }

    /**
     * calculate distance between two geo location
     * @param prevLatitude
     * @param preLongitude
     * @param newLatitude
     * @param newLongitude
     * @return
     */
    private Double getDistance(double prevLatitude, double preLongitude, double newLatitude, double newLongitude) {
        android.location.Location loc1 = new android.location.Location("");
        loc1.setLatitude(prevLatitude);
        loc1.setLongitude(preLongitude);
        android.location.Location loc2 = new android.location.Location("");
        loc2.setLatitude(newLatitude);
        loc2.setLongitude(newLongitude);
        double distanceInMeters = loc1.distanceTo(loc2);
        return Math.abs(distanceInMeters);
    }

    @SuppressLint("MissingPermission")
    @Override
    public void onMapReady(GoogleMap googleMap) {
        final Permission permission = new Permission(getApplicationContext(), OnTripActivity.this);
        gmap = googleMap;
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                gmap.setMinZoomPreference(1);
                gmap.setMaxZoomPreference(20);
                if (!permission.isLocationPermissionGranted()) {
                    permission.checkPermissions();
                    return;
                }
                gmap.setTrafficEnabled(true);
                gmap.setMyLocationEnabled(true);
                gmap.addMarker(new MarkerOptions().position(new LatLng(tripModel.getPickupLocation().getLatitude(), tripModel.getPickupLocation().getLongitude())));
                gmap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 16.0f));
                gmap.setOnMyLocationButtonClickListener(new GoogleMap.OnMyLocationButtonClickListener() {
                    @Override
                    public boolean onMyLocationButtonClick() {
                        gmap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 16.0f));
                        return false;
                    }
                });
            }
        });
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        Bundle mapViewBundle = outState.getBundle(MAP_VIEW_BUNDLE_KEY);
        if (mapViewBundle == null) {
            mapViewBundle = new Bundle();
            outState.putBundle(MAP_VIEW_BUNDLE_KEY, mapViewBundle);
        }

        mapView.onSaveInstanceState(mapViewBundle);
    }

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        if (checker) {
            new LoginSession(getApplicationContext()).setDriverState(KeyString.ONLINE);
            DriverState state = new DriverState(mSocket.id(), new LoginSession(getApplicationContext()).getDriverState(), new LoginSession(getApplicationContext()).get_Id());
            boolean checker = true;
            while (checker) {
                if (mSocket.connected()) {
                    try {
                        mSocket.emit(KeyString.UPDATE_DRIVER_STATE_SOCKET, new JSONObject(new Gson().toJson(state, DriverState.class)));
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    checker = false;
                }
            }
            //onBackPressed();
            finish();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        mapView.onResume();
    }

    @Override
    public void onStart() {
        super.onStart();
        mapView.onStart();
    }

    @Override
    public void onStop() {
        super.onStop();
        mapView.onStop();
    }

    @Override
    public void onPause() {
        mapView.onPause();
        if (checker) {
            new LoginSession(getApplicationContext()).setDriverState(KeyString.ONLINE);
            DriverState state = new DriverState(mSocket.id(), new LoginSession(getApplicationContext()).getDriverState(), new LoginSession(getApplicationContext()).get_Id());
            boolean checker = true;
            while (checker) {
                if (mSocket.connected()) {
                    try {
                        mSocket.emit(KeyString.UPDATE_DRIVER_STATE_SOCKET, new JSONObject(new Gson().toJson(state, DriverState.class)));
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    checker = false;
                }
            }
            //onBackPressed();
            finish();
        }
        super.onPause();
    }

    @Override
    public void onDestroy() {
        this.mWakeLock.release();
        mapView.onDestroy();

//        SharedPreferences prefs = getSharedPreferences("X", MODE_PRIVATE);
//        SharedPreferences.Editor editor = prefs.edit();
//        editor.putString("lastActivity", getClass().getName());
//        editor.commit();

        if (new LoginSession(getApplicationContext()).getDriverState().equals(KeyString.GOING_TO_PICKUP) || new LoginSession(getApplicationContext()).getDriverState().equals(KeyString.ON_TRIP)) {
            TripSession session = new TripSession(getApplicationContext());
            session.setTripModel(tripModel);
            session.setTripPriceModel(tripPriceModel);
            session.setDriverState(new LoginSession(getApplicationContext()).getDriverState());
            session.setLastActivity(getClass().getName());
            session.setLastLatitude(lastLatitude);
            session.setLastLongitude(lastLongitude);
            session.setPrevDistance(prevDistance);
            session.setTotalDistance(totalDistance);
            session.setTotalTimeMillis(totalTimeMillis);
            session.setWaitTimeMillis(waitTimeMillis);
        } else {
            new TripSession(getApplicationContext()).clearTripSession();
        }

        super.onDestroy();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        mapView.onLowMemory();
    }
}
