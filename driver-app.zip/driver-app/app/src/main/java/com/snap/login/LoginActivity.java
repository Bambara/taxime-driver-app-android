package com.snap.login;

import android.app.ProgressDialog;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.snap.R;
import com.snap.config.Permission;
import com.snap.home.HomeActivity;
import com.snap.model.driverCheckInformationModel.DriverCheckRequestModel;
import com.snap.model.driverCheckInformationModel.DriverCheckResponseModel;
import com.snap.other.DriverNotApprovedActivity;
import com.snap.register.RegisterActivity;
import com.snap.rest.ApiInterface;
import com.snap.rest.JsonApiClient;
import com.snap.session.LoginSession;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {
    private Button nextButton, registerButton;
    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loging);

        new Permission(getApplicationContext(), LoginActivity.this).checkPermissions();

        LoginSession session = new LoginSession(getApplicationContext());
        if (session.isLoggedIn() && session.getDriverApprove()) {
            Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        } else if (session.isLoggedIn() && !session.getDriverApprove()) {
            checkDriver();
        }

        nextButton = findViewById(R.id.next_button);
        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MobileNumberActivity.class);
                startActivity(intent);
            }
        });

        registerButton = findViewById(R.id.register_button);
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), RegisterActivity.class);
                startActivity(intent);
            }
        });

    }

    /**
     * check driver approved or not
     */
    public void checkDriver() {
        DriverCheckRequestModel model = new DriverCheckRequestModel();
        LoginSession session = new LoginSession(getApplicationContext());
        model.setDriverId(session.getUserDetails().getContent().getId());
        model.setVehicleId(null);

        progressDialog = new ProgressDialog(LoginActivity.this);
        progressDialog.setMessage("Loading...");
        progressDialog.show();
        ApiInterface apiInterface = JsonApiClient.getApiClient().create(ApiInterface.class);
        Call<DriverCheckResponseModel> call = apiInterface.driverCheck(model);
        call.enqueue(new Callback<DriverCheckResponseModel>() {
            @Override
            public void onResponse(Call<DriverCheckResponseModel> call, Response<DriverCheckResponseModel> response) {
                progressDialog.dismiss();
                Log.i("TAG CHECK DRIVER CODE", String.valueOf(response.code()));
                LoginSession session1 = new LoginSession(getApplicationContext());
                if (response.code() == 206 && response.body().getDriverDispatch().get(0).isApproved()) {
                    session1.setDriverEnable(response.body().getDriverDispatch().get(0).isEnable());
                    session1.setDispatcherEnable(response.body().getDriverDispatch().get(0).isDispatchEnable());
                    session1.setDriverApprove(true);
                    Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    finish();
                } else {
                    Intent intent = new Intent(getApplicationContext(), DriverNotApprovedActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    finish();
                }
            }

            @Override
            public void onFailure(Call<DriverCheckResponseModel> call, Throwable t) {
                progressDialog.dismiss();
                Log.i("TAG CHECK DRIVER FAIL", t.getMessage());
                Intent intent = new Intent(getApplicationContext(), DriverNotApprovedActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                finish();
            }
        });
    }
}
