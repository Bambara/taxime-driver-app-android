package com.snap.session;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

import com.google.gson.Gson;
import com.snap.config.KeyString;
import com.snap.login.LoginActivity;
import com.snap.model.LoginModel;
import com.snap.model.driverCheckInformationModel.DriverCheckResponseModel;
import com.snap.model.vehicleModel.Content;

public class LoginSession {

    static SharedPreferences pref; // Shared Preferences
    Editor editor;  // Editor for Shared preferences
    Context _context;   // Context
    int PRIVATE_MODE = 0;   // Shared pref mode
    private static final String PREF_NAME = "Login";   // Sharedpref file name
    private static final String IS_LOGIN = "IsLoggedIn";
    private static final String ID = "id";
    private static final String FIRST_NAME = "firstName";
    private static final String LAST_NAME = "lastName";
    private static final String PROFILE_PICTURE = "profilePicture";
    private static final String TOKEN = "token";
    private static final String DRIVER_STATE = "driverState";
    private static final String BIRTHDAY = "birthday";
    private static final String ADDRESS = "address";
    private static final String CONTACT_NUMBER = "contactNumber";
    private static final String EMAIL = "email";
    private static final String VEHICLE = "vehicle";
    private static final String DISPATCHER = "dispatcher";
    private static final String DRIVER_APPROVE = "Driver Approve";
    private static final String DRIVER_ENABLE = "Driver Enable";
    private static final String VEHICLE_ENABLE = "Vehicle Enable";
    private static final String DISPATCHER_ENABLE = "Dispatcher Enable";
    private static final String SOCKET_ID = "Socket Id";
    private static final String _ID = "_id";
    private static final String CATEGORY_IMAGE = "categoryImage";

    // Constructor
    public LoginSession(Context context){
        this._context = context;
        pref = _context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        editor = pref.edit();
    }

    /**
     * stored dispatcher data and get dispatcher data in session
     */
    public void createDispatcherSession(DriverCheckResponseModel.DriverDispatch.Dispatcher model) {
        Gson gson = new Gson();
        String json = gson.toJson(model);
        editor.putString(DISPATCHER, json);
        editor.commit();
    }
    public DriverCheckResponseModel.DriverDispatch.Dispatcher getDispatcher() {
        Gson gson = new Gson();
        String json = pref.getString(DISPATCHER, null);
        DriverCheckResponseModel.DriverDispatch.Dispatcher object = gson.fromJson(json, DriverCheckResponseModel.DriverDispatch.Dispatcher.class);
        return object;
    }

    /**
     * set and get socket id
     */
    public void setSocketId (String id) {
        editor.putString(SOCKET_ID, id);
        editor.commit();
    }
    public String getSocketId() {
        return pref.getString(SOCKET_ID, null);
    }
    public void set_Id(String id) {
        editor.putString(_ID, id);
        editor.commit();
    }
    public String get_Id() {
        return pref.getString(_ID, null);
    }

    /**
     * set and get driver approved or not
     */
    public void setDriverApprove(boolean state) {
        editor.putBoolean(DRIVER_APPROVE, state);
        editor.commit();
    }
    public boolean getDriverApprove() {
        return pref.getBoolean(DRIVER_APPROVE, false);
    }

    /**
     * set and get driver enable and disable
     */
    public void setDriverEnable(boolean state) {
        editor.putBoolean(DRIVER_ENABLE, state);
        editor.commit();
    }
    public boolean getDriverEnable(){
        return pref.getBoolean(DRIVER_ENABLE,false);
    }

    /**
     * set nad get dispatcher enable and disable
     */
    public void setDispatcherEnable(boolean state) {
        editor.putBoolean(DISPATCHER_ENABLE, state);
        editor.commit();
    }
    public boolean getDispatcherEnale() {
        return pref.getBoolean(DISPATCHER_ENABLE, false);
    }

    /**
     * set nad get vehicle enable and disable
     */
    public void setVehicleEnable(boolean state) {
        editor.putBoolean(VEHICLE_ENABLE, state);
        editor.commit();
    }
    public boolean getVehicleEnable() {
        return pref.getBoolean(VEHICLE_ENABLE, false);
    }

    /**
     * store sub category images
     * @param categoryImage
     */
    public void createSubCategoryImageSession(DriverCheckResponseModel.CategoryImage categoryImage) {
        Gson gson = new Gson();
        String json = gson.toJson(categoryImage);
        editor.putString(CATEGORY_IMAGE, json);
        editor.commit();
    }

    /**
     * get sub category images from session
     * @return
     */
    public DriverCheckResponseModel.CategoryImage getCategoryImage() {
        Gson gson = new Gson();
        String json = pref.getString(CATEGORY_IMAGE, null);
        DriverCheckResponseModel.CategoryImage object = gson.fromJson(json, DriverCheckResponseModel.CategoryImage.class);
        return object;
    }

    /**
     * store vehicle data in session
     */
    public void createVehicleSession(Content content) {
        Gson gson = new Gson();
        String json = gson.toJson(content);
        editor.putString(VEHICLE, json);
        editor.commit();
    }

    /**
     * get vehicle data from session
     */
    public Content getVehicle() {
        Gson gson = new Gson();
        String json = pref.getString(VEHICLE, null);
        Content object = gson.fromJson(json, Content.class);
        return object;
    }

    /**
     * Create login session
     * */
    public void createLoginSession(LoginModel model){

        editor.putBoolean(IS_LOGIN, true);  // Storing login value as TRUE
        editor.putString(ID, model.getContent().getId());   // Storing name in pref
        editor.putString(FIRST_NAME, model.getContent().getFirstName());
        editor.putString(LAST_NAME, model.getContent().getLastName());
        editor.putString(PROFILE_PICTURE, KeyString.BASE_URL + model.getContent().getProfileImage());
        editor.putString(TOKEN, model.getToken());
        editor.putString(BIRTHDAY, model.getContent().getBirthday());
        editor.putString(ADDRESS, model.getContent().getAddress().getAddress() + ", " + model.getContent().getAddress().getStreet() + ", " + model.getContent().getAddress().getCity());
        editor.putString(CONTACT_NUMBER, model.getContent().getContactNo());
        editor.putString(EMAIL, model.getContent().getEmail());
        editor.commit();    // commit changes
    }

    /**
     * set driver state
     */
    public void setDriverState(String state) {
        editor.putString(DRIVER_STATE, state);
        editor.commit();
    }

    /**
     * get driver state
     */
    public String getDriverState() {
        return pref.getString(DRIVER_STATE, KeyString.OFFLINE);
    }

    /**
     * Check login method wil check user login status
     * If false it will redirect user to login page
     * Else won't do anything
     * */
    public void checkLogin(){
        // Check login status
        if(!this.isLoggedIn()){

            Intent intent = new Intent(_context, LoginActivity.class);   // user is not logged in redirect him to Login Activity
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP); // Closing all the Activities
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);  // Add new Flag to start new Activity
            _context.startActivity(intent);  // Staring Login Activity
        }
    }



    /**
     * Get stored session data
     * */
    public LoginModel getUserDetails(){
        LoginModel loginModel = new LoginModel();
        LoginModel.Content content = new LoginModel.Content();
        content.setFirstName(pref.getString(FIRST_NAME, null));
        content.setLastName(pref.getString(LAST_NAME, null));
        content.setId(pref.getString(ID, null));
        content.setProfileImage(pref.getString(PROFILE_PICTURE, null));
        content.setBirthday(pref.getString(BIRTHDAY, null));
        LoginModel.Content.Address address = new LoginModel.Content.Address();
        address.setAddress(pref.getString(ADDRESS, null));
        content.setAddress(address);
        content.setContactNo(pref.getString(CONTACT_NUMBER, null));
        content.setEmail(pref.getString(EMAIL, null));
        loginModel.setContent(content);
        loginModel.setToken(pref.getString(TOKEN, null));
        return loginModel;
    }

    /**
     * Clear session details
     * */
    public void logoutUser(){
        // Clearing all data from Shared Preferences
        editor.clear();
        editor.commit();

        Intent intent = new Intent(_context, LoginActivity.class);   // After logout redirect user to Login Activity
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        _context.startActivity(intent);  // Staring Login Activity
    }
    public void clearSession(){
        // Clearing all data from Shared Preferences
        editor.clear();
        editor.commit();
    }

    /**
     * Quick check for login
     * **/
    // Get Login State
    public boolean isLoggedIn(){
        return pref.getBoolean(IS_LOGIN, false);
    }
}
