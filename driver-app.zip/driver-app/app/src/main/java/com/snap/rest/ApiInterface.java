package com.snap.rest;

import com.snap.model.AndroidAppVersionModel;
import com.snap.model.DispatchHistoryModel;
import com.snap.model.tripCancelModel.DispatchTripCancelRequestModel;
import com.snap.model.DispatchTripEndRequestModel;
import com.snap.model.HiresListModel;
import com.snap.model.PassengerTripEndRequestModel;
import com.snap.model.WalletDataModel;
import com.snap.model.driverConnectModel.DriverConnectedModel;
import com.snap.model.dispatchEstimatedCostModel.EstimatedCostRequestModel;
import com.snap.model.dispatchEstimatedCostModel.EstimatedCostResponseModel;
import com.snap.model.driverCheckInformationModel.DriverCheckRequestModel;
import com.snap.model.driverCheckInformationModel.DriverCheckResponseModel;
import com.snap.model.roadPickupModel.EndRoadPickupTripModel;
import com.snap.model.LoginModel;
import com.snap.model.roadPickupModel.StartRoadPickupTripRequestModel;
import com.snap.model.roadPickupModel.StartRoadPickupTripResponceModel;
import com.snap.model.dispatchModel.DispatchModel;
import com.snap.model.mapDistanceModel.MapDistanceModel;
import com.snap.model.tripAcceptModel.DispatchTripAcceptRequestModel;
import com.snap.model.tripAcceptModel.PassengerTripAcceptRequestModel;
import com.snap.model.tripAcceptModel.TripAcceptResponseModel;
import com.snap.model.tripCancelModel.PassengerTripCancelRequestModel;
import com.snap.model.vehicalCategoryModel.VehicleCategoryRequestModel;
import com.snap.model.vehicalCategoryModel.VehicleCategoryResponseModel;
import com.snap.model.vehicleModel.VehicleModel;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ApiInterface {
    @Multipart
    @POST("/driver/driverregister")
    Call<ResponseBody> driverRegister(
            @Part("firstName") RequestBody firstName,
            @Part("lastName") RequestBody lastName,
            @Part("email") RequestBody email,
            @Part("nic") RequestBody nicNumber,
            @Part("birthday") RequestBody birthday,
            @Part("mobile") RequestBody mobileNumber,
            @Part("gender") RequestBody gender,
            @Part("address") RequestBody addressLineOne,
            @Part("street") RequestBody addressLineTwo,
            @Part("city") RequestBody city,
            @Part("zipcode") RequestBody postalCode,
            @Part("country") RequestBody country,
            @Part MultipartBody.Part nicFrontImage,
            @Part MultipartBody.Part nicBackImage,
            @Part MultipartBody.Part licenceFrontImage,
            @Part MultipartBody.Part licenceBackImage,
            @Part("lifeInsuranceNo") RequestBody lifeInsuranceNo,
            @Part("lifeInsuranceExpiryDate") RequestBody lifeInsuranceExpiryDate,
            @Part MultipartBody.Part profileImage,
            @Part(" lifeInsuranceAmount") RequestBody lifeInsuranceAmount
    );

    @Multipart
    @POST("/driver/updatedriverimagesbyid")
    Call<ResponseBody> driverImageUpdate(
            @Part("driverId") RequestBody driverId,
            @Part MultipartBody.Part profileImage,
            @Part MultipartBody.Part nicFrontImage,
            @Part MultipartBody.Part nicBackImage,
            @Part MultipartBody.Part licenceFrontImage,
            @Part MultipartBody.Part licenceBackImage
    );

    @Multipart
    @POST("/driver/addvehicle")
    Call<ResponseBody> addVehicle(
            @Part("ownerContactName") RequestBody ownerContactName,
            @Part("ownerContactNumber") RequestBody ownerContactNumber,
            @Part("ownerContactEmail") RequestBody ownerContactEmail,
            @Part("vehicleRegistrationNo") RequestBody   vehicleRegistrationNo,
            @Part("vehicleColor") RequestBody vehicleColor,
            @Part("vehicleBrandName") RequestBody vehicleBrandName,
            @Part MultipartBody.Part vehicleBookPic,
            @Part MultipartBody.Part vehicleInsurancePic,
            @Part MultipartBody.Part vehicleFrontPic,
            @Part MultipartBody.Part vehicleSideViewPic,
            @Part("driverId") RequestBody driverId,
            @Part("vehicleModel") RequestBody vehicleModel,
            @Part("weightLimit") RequestBody weightLimit,
            @Part("passengerCapacity") RequestBody passengerCapacity
    );

    @Multipart
    @POST("/vehicle/updatevehicleimagesbyid")
    Call<ResponseBody> vehicleImageUpdate(
            @Part("vehicleId") RequestBody vehicleId,
            @Part MultipartBody.Part vehicleBookPic,
            @Part MultipartBody.Part vehicleInsurancePic,
            @Part MultipartBody.Part vehicleFrontPic,
            @Part MultipartBody.Part vehicleSideViewPic
    );

    @POST("/driver/driverlogin")
    Call<LoginModel> signIn(@Body LoginModel loginModel);

    @POST("/driver/sendotp")
    Call<LoginModel> sendOtp(@Body LoginModel loginModel);

    @POST("/driver/getotp")
    Call<LoginModel> resendOtp(@Body LoginModel loginModel);

    @GET("api/directions/json?key=AIzaSyBA7M0LHCtRo2aB8b0n0xZOBL68lfCBt2A")
    Call<MapDistanceModel> getDistanceDuration(@Query("units") String units, @Query("origin") String origin, @Query("destination") String destination, @Query("mode") String mode);

    @POST("/vehicleCategory/getCategoryAllDataTimeAndLocationBased")
    Call<VehicleCategoryResponseModel> getVehicleCategory(@Body VehicleCategoryRequestModel model);

    @POST("/dispatch/addDispatch")
    Call<ResponseBody> addDispatch(@Body DispatchModel dispatchModel);

    @POST("/driver/getvehicledetails")
    Call<VehicleModel> getVehicle(@Body DriverConnectedModel driverConnectedModel);

//    @POST("/dispatch/acceptdispatch")
//    Call<ResponseBody> acceptdispatch(@Body DispatchAcceptModel dispatchAcceptModel);

    @POST("/roadPickup/startRoadPickupTrip")
    Call<StartRoadPickupTripResponceModel> startRoadPickup(@Body StartRoadPickupTripRequestModel startRoadPickupTripRequestModel);

    @POST("/roadPickup/endRoadPickupTrip")
    Call<ResponseBody> endRoadPickup(@Body EndRoadPickupTripModel endRoadPickupTripModel);

    @POST("/driver/checkinformation")
    Call<DriverCheckResponseModel> driverCheck(@Body DriverCheckRequestModel driverCheckRequestModel);

    @POST("/driver/selectvehicle")
    Call<ResponseBody> selectVehicle(@Body DriverCheckRequestModel driverCheckRequestModel);

    @POST("/dispatch/getEstimatedCost")
    Call<EstimatedCostResponseModel> getDispatchEstimatedCost(@Body EstimatedCostRequestModel estimatedCostRequestModel);

    @POST("/dispatch/acceptdispatch")
    Call<TripAcceptResponseModel> acceptDispatch(@Body DispatchTripAcceptRequestModel tripAcceptRequestModel);

    @POST("/trip/acceptlivetrip")
    Call<TripAcceptResponseModel> acceptLiveTrip(@Body PassengerTripAcceptRequestModel tripAcceptRequestModel);

    @POST("/dispatch/enddispatch")
    Call<ResponseBody> endDispatchTrip(@Body DispatchTripEndRequestModel dispatchTripEndRequestModel);

    @POST("/trip/endlivetrip")
    Call<ResponseBody> endPassengerTrip(@Body PassengerTripEndRequestModel passengerTripEndRequestModel);

    @POST("/dispatch/canceldispatch")
    Call<ResponseBody> cancelDispatchTrip(@Body DispatchTripCancelRequestModel dispatchTripCancelRequestModel);

    @POST("/trip/cancelbydriver")
    Call<ResponseBody> cancelPassengerTrip(@Body PassengerTripCancelRequestModel passengerTripCancelRequestModel);

    @GET("/driver/getLatestAndroidVersion")
    Call<AndroidAppVersionModel> appVersionCheck();

    @GET("/driver/getTrips/{driverid}")
    Call<HiresListModel> getDriverTrips(@Path("driverid") String driverId);

    @GET("/driver/getDispatches/{driverid}")
    Call<DispatchHistoryModel> getDispatchHistory(@Path("driverid") String driverId);

    @GET("/driver/getTripStatData/{driverid}")
    Call<WalletDataModel> getWalletData(@Path("driverid") String driverId);
}
