package com.snap.home.driver;

import android.annotation.SuppressLint;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.core.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

import com.snap.R;
import com.snap.home.dispatcher.DispatcherFragment;

public class DriverFragment extends Fragment {

    private Button switchDispatchButton, bookingButton, preBookingButton, longTripButton;

    public static DriverFragment newInstance() {
        DriverFragment fragment = new DriverFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @SuppressLint("ResourceAsColor")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View myFragmentView =  inflater.inflate(R.layout.fragment_driver, container, false);
        /**
         * set status bar colour
         */
        Window window = getActivity().getWindow();   // clear FLAG_TRANSLUCENT_STATUS flag:
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);  // add FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS flag to the window
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);   // finally change the color
        window.setStatusBarColor(ContextCompat.getColor(getContext(), R.color.redOne));

        getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.driver_fragment, BookingsFragment.newInstance()).commit();

        switchDispatchButton = myFragmentView.findViewById(R.id.dispatch_button);
        switchDispatchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                AlertDialog alertDialog = new AlertDialog.Builder(getContext()).create();
//                alertDialog.setTitle("Service Not Available");
//                alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
//                        new DialogInterface.OnClickListener() {
//                            public void onClick(DialogInterface dialog, int which) {
//                                dialog.dismiss();
//                            }
//                        });
//                alertDialog.show();
                getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.fragment, DispatcherFragment.newInstance()).commit();
            }
        });
        preBookingButton = myFragmentView.findViewById(R.id.pre_booking_button);
        preBookingButton.setVisibility(View.INVISIBLE);
        longTripButton = myFragmentView.findViewById(R.id.long_trip_button);
        longTripButton.setVisibility(View.INVISIBLE);

        return myFragmentView;
    }
}
