package com.snap.login;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.snap.R;
import com.snap.config.KeyString;
import com.snap.config.SoftKeyboard;
import com.snap.home.HomeActivity;
import com.snap.model.LoginModel;
import com.snap.profile.AddVehicleActivity;
import com.snap.rest.ApiInterface;
import com.snap.rest.JsonApiClient;
import com.snap.session.LoginSession;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class OTPVerificationActivity extends AppCompatActivity {
    private Button nextButton;
    private EditText pinOne, pinTwo, pinThree, pinFour;
    ProgressDialog progressDialog;
    private ImageView profileImage;
    private TextView name;
    String profileImagePath, firstName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otpverification);

        findViewById(R.id.root_layout_otp_verification_activity).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                SoftKeyboard.hideSoftKeyboard(OTPVerificationActivity.this);
                return false;
            }
        });

        pinOne = findViewById(R.id.pinOne);
        pinTwo = findViewById(R.id.pinTwo);
        pinThree = findViewById(R.id.pinThree);
        pinFour = findViewById(R.id.pinFour);

        profileImagePath = getIntent().getStringExtra(KeyString.PROFILE_IMAGE);
        profileImage = findViewById(R.id.profile_image);
        Glide.with(this).load(profileImagePath).into(profileImage);
//        File imageFile = new File(profileImagePath);
//        Bitmap bitmap = BitmapFactory.decodeFile(imageFile.getAbsolutePath());
//        profileImage.setImageBitmap(bitmap);

        firstName = getIntent().getStringExtra(KeyString.FIRST_NAME);
        name = findViewById(R.id.name);
        name.setText(firstName);

        nextButton = findViewById(R.id.next_button);
        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                otpValidate(fetchData());
            }
        });

        pinBorderSetUp();
    }

    private LoginModel fetchData() {
        String mobileNumber = getIntent().getStringExtra(KeyString.MOBILE_NUMBER);
        LoginModel model = new LoginModel();
        try {
            String otp = pinOne.getText().toString() + pinTwo.getText().toString() + pinThree.getText().toString() + pinFour.getText().toString();
            model.setPin(Integer.parseInt(otp));
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(),"Invalid Pin", Toast.LENGTH_SHORT).show();
        }
        model.setMobileNumber(mobileNumber);
        return model;
    }

    /**
     * otp validation api call
     * @param model
     */
    private void otpValidate(LoginModel model){
        Log.i("TAG OTP", String.valueOf(model.getPin()));
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading...");
        progressDialog.show();
        ApiInterface apiInterface = JsonApiClient.getApiClient().create(ApiInterface.class);
        Call<LoginModel> call = apiInterface.signIn(model);
        call.enqueue(new Callback<LoginModel>() {
            @Override
            public void onResponse(Call<LoginModel> call, Response<LoginModel> response) {
                progressDialog.dismiss();
                Log.i("TAG CODE", String.valueOf(response.code()));
                if (response.code() == 200){
                    LoginSession session = new LoginSession(getApplicationContext());
                    session.createLoginSession(response.body());
                    session.setDriverState(KeyString.OFFLINE);
                    session.createVehicleSession(null);
                    session.setDriverApprove(true);
                    session.setDriverEnable(true);
                    session.setDispatcherEnable(true);
                    session.setVehicleEnable(true);

                    Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
                    intent.putExtra(KeyString.PROFILE_IMAGE, profileImagePath);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);  // Add new Flag to start new Activity
                    startActivity(intent);
                    //finish();
                } else if (response.code() == 202){
                    LoginSession session = new LoginSession(getApplicationContext());
                    session.createLoginSession(response.body());
                    session.setDriverState(KeyString.OFFLINE);
                    session.createVehicleSession(null);
                    session.setDriverApprove(false);
                    session.setDriverEnable(false);
                    session.setDispatcherEnable(false);
                    session.setVehicleEnable(false);
                    //Intent intent = new Intent(getApplicationContext(), DriverNotApprovedActivity.class);
                    Intent intent = new Intent(getApplicationContext(), AddVehicleActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                } else {
                    AlertDialog alertDialog = new AlertDialog.Builder(OTPVerificationActivity.this).create();
                    alertDialog.setTitle("Invalid PIN Number");
                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.show();
                }

            }

            @Override
            public void onFailure(Call<LoginModel> call, Throwable t) {
                progressDialog.dismiss();
                Log.i("TAG CODE", t.getMessage());
                AlertDialog alertDialog = new AlertDialog.Builder(OTPVerificationActivity.this).create();
                alertDialog.setTitle("Something went wrong");
                alertDialog.setMessage("check your internet connection and try again");
                alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                alertDialog.show();
            }
        });
    }

    /**
     * set border color in otp number input field
     */
    private void pinBorderSetUp() {
        pinOne.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (!s.toString().isEmpty()) {
                    pinOne.setBackground(getDrawable(R.drawable.ash_view_background_with_green_redious_boder));
                    pinTwo.requestFocus();
                } else {
                    pinOne.setBackground(getDrawable(R.drawable.ash_view_background_with_white_redious_boder));
                }
            }
        });
        pinTwo.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (!s.toString().isEmpty()) {
                    pinTwo.setBackground(getDrawable(R.drawable.ash_view_background_with_green_redious_boder));
                    pinThree.requestFocus();
                } else {
                    pinTwo.setBackground(getDrawable(R.drawable.ash_view_background_with_white_redious_boder));
                    if (pinThree.getText().toString().isEmpty()) {
                        pinOne.requestFocus();
                    }
                }
            }
        });
        pinThree.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (!s.toString().isEmpty()) {
                    pinThree.setBackground(getDrawable(R.drawable.ash_view_background_with_green_redious_boder));
                    pinFour.requestFocus();
                } else {
                    pinThree.setBackground(getDrawable(R.drawable.ash_view_background_with_white_redious_boder));
                    if (pinFour.getText().toString().isEmpty()) {
                        pinTwo.requestFocus();
                    }
                }
            }
        });
        pinFour.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (!s.toString().isEmpty()) {
                    pinFour.setBackground(getDrawable(R.drawable.ash_view_background_with_green_redious_boder));
                } else {
                    pinFour.setBackground(getDrawable(R.drawable.ash_view_background_with_white_redious_boder));
                    pinThree.requestFocus();
                }
            }
        });
    }
}
