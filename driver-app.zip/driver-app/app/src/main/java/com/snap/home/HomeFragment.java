package com.snap.home;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.core.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.CompoundButton;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.gson.Gson;
import com.kyleduo.switchbutton.SwitchButton;
import com.snap.R;
import com.snap.config.KeyString;
import com.snap.config.Permission;
import com.snap.gps.GPSTracker;
import com.snap.home.dispatcher.DispatcherFragment;
import com.snap.home.driver.DriverFragment;
import com.snap.home.road_pickup.PassengerInfoActivity;
import com.snap.model.DriverState;
import com.snap.other.VehicleSelecterPopup;
import com.snap.session.LoginSession;
import com.snap.socket.MySocket;

import org.json.JSONException;
import org.json.JSONObject;

public class HomeFragment extends Fragment implements OnMapReadyCallback {

    private static final String MAP_VIEW_BUNDLE_KEY = "MapViewBundleKey";
    private GoogleMap gmap;
    private MapView mapView;
    private GPSTracker location;
    LatLng latLng;
    private com.github.nkzawa.socketio.client.Socket mSocket;
    private SwitchButton onlineSwitch;
    private ConstraintLayout dispatcherButton, driverButton, roadPickupButton;
    public TextView tripCount, connectionState;

    public static HomeFragment newInstance() {
        HomeFragment fragment = new HomeFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MySocket socket = (MySocket)getActivity().getApplication();
        mSocket = socket.getmSocket();
    }

    @SuppressLint("ResourceAsColor")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View myFragmentView = inflater.inflate(R.layout.fragment_home, container, false);
        /**
         * set status bar colour
         */
        Window window = this.getActivity().getWindow();   // clear FLAG_TRANSLUCENT_STATUS flag:
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);  // add FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS flag to the window
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);   // finally change the color
        window.setStatusBarColor(ContextCompat.getColor(getContext(), R.color.greenOne));

//        myFragmentView.findViewById(R.id.test).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                DriverDisconnectModel model = new DriverDisconnectModel();
//                LoginSession session = new LoginSession(getContext());
//                model.setDriverId(session.getUserDetails().getContent().getId());
//                model.set_id(session.get_Id());
//                model.setSocketId(session.getSocketId());
//                try {
//                    mSocket.emit(KeyString.RECON, new JSONObject(new Gson().toJson(model, DriverDisconnectModel.class)));
//                } catch (Exception e) {
//
//                }
//            }
//        });

        connectionState = myFragmentView.findViewById(R.id.socket_state);
        connectionState.setText(R.string.connecting);

        location = new GPSTracker(getContext());
        latLng = new LatLng(location.getLatitude(), location.getLongitude());
        Bundle mapViewBundle = null;
        if (savedInstanceState != null) {
            mapViewBundle = savedInstanceState.getBundle(MAP_VIEW_BUNDLE_KEY);
        }

        tripCount = myFragmentView.findViewById(R.id.trip_count);

        mapView = myFragmentView.findViewById(R.id.map_view);
        mapView.onCreate(mapViewBundle);
        mapView.getMapAsync(this);

        onlineSwitch = myFragmentView.findViewById(R.id.online_switch);
        onlineSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                LoginSession session = new LoginSession(getContext());
                Permission permission = new Permission(getContext(), getActivity());
                if (!permission.isLocationPermissionGranted()) {
                    permission.checkPermissions();
                    buttonView.setChecked(false);
                    return;
                }

                if (session.getDriverState().equals(KeyString.OFFLINE) && session.getVehicle() == null) {
                    AlertDialog alertDialog = new AlertDialog.Builder(getContext()).create();
                    alertDialog.setTitle("No Vehicle");
                    alertDialog.setMessage("You have no selected vehicle");
                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Select Vehicle",
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    new VehicleSelecterPopup(getContext(), getActivity());
                                }
                            });
                    alertDialog.show();
                    buttonView.setChecked(false);
                    return;
                } else if (new LoginSession(getContext()).getDriverEnable() == false) {
                    AlertDialog alertDialog = new AlertDialog.Builder(getContext()).create();
                    alertDialog.setTitle("Driver Disable");
                    alertDialog.setMessage("your account temporally disable contact snap team");
                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.show();
                    buttonView.setChecked(false);
                    return;
                }

                if (isChecked) {
                    onlineSwitch.setBackDrawable(getResources().getDrawable(R.drawable.switch_online_background));
                    onlineSwitch.setThumbDrawable(getResources().getDrawable(R.drawable.switch_online_thumb));
                    session.setDriverState(KeyString.ONLINE);
                } else {
                    onlineSwitch.setBackDrawable(getResources().getDrawable(R.drawable.switch_offline_background));
                    onlineSwitch.setThumbDrawable(getResources().getDrawable(R.drawable.switch_offline_thumb));
                    session.setDriverState(KeyString.OFFLINE);
                }
                DriverState state = new DriverState(mSocket.id(), session.getDriverState(), new LoginSession(getContext()).get_Id());
                //if (!mSocket.connected()) new SocketReconnect(getContext(), mSocket);
                try {
                    mSocket.emit(KeyString.UPDATE_DRIVER_STATE_SOCKET, new JSONObject(new Gson().toJson(state, DriverState.class)));
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
        if (!new LoginSession(getContext()).getDriverState().equals(KeyString.OFFLINE)) {
            onlineSwitch.setChecked(true);
            onlineSwitch.setBackDrawable(getResources().getDrawable(R.drawable.switch_online_background));
            onlineSwitch.setThumbDrawable(getResources().getDrawable(R.drawable.switch_online_thumb));
        }

        dispatcherButton = myFragmentView.findViewById(R.id.dispatcher_button);
        driverButton = myFragmentView.findViewById(R.id.driver_button);
        roadPickupButton = myFragmentView.findViewById(R.id.road_pickup_button);
        dispatcherButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                AlertDialog alertDialog = new AlertDialog.Builder(getContext()).create();
//                alertDialog.setTitle("Service Not Available");
//                alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
//                        new DialogInterface.OnClickListener() {
//                            public void onClick(DialogInterface dialog, int which) {
//                                dialog.dismiss();
//                            }
//                        });
//                alertDialog.show();
                getFragmentManager().beginTransaction().replace(R.id.fragment, DispatcherFragment.newInstance()).commit();
            }
        });
        driverButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                AlertDialog alertDialog = new AlertDialog.Builder(getContext()).create();
//                alertDialog.setTitle("Service Not Available");
//                alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
//                        new DialogInterface.OnClickListener() {
//                            public void onClick(DialogInterface dialog, int which) {
//                                dialog.dismiss();
//                            }
//                        });
//                alertDialog.show();
                if (!new LoginSession(getContext()).getDriverState().equals(KeyString.ONLINE)) {
                    AlertDialog alertDialog = new AlertDialog.Builder(getContext()).create();
                    alertDialog.setTitle("Driver Offline");
                    alertDialog.setMessage("please change driver state as online");
                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.show();
                } else {
                    getFragmentManager().beginTransaction().replace(R.id.fragment, DriverFragment.newInstance()).commit();
                }
            }
        });
        roadPickupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (new LoginSession(getContext()).getVehicle() == null) {
                    AlertDialog alertDialog = new AlertDialog.Builder(getContext()).create();
                    alertDialog.setTitle("No Vehicle");
                    alertDialog.setMessage("You have no available vehicle");
                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Select Vehicle",
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    new VehicleSelecterPopup(getContext(), getActivity());
                                }
                            });
                    alertDialog.show();
                    return;
                } else if (!new LoginSession(getContext()).getDriverState().equals(KeyString.ONLINE)) {
                    AlertDialog alertDialog = new AlertDialog.Builder(getContext()).create();
                    alertDialog.setTitle("Driver Offline");
                    alertDialog.setMessage("please change driver state as online");
                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.show();
                    return;
                }
                Intent intent = new Intent(getContext(), PassengerInfoActivity.class);
                startActivity(intent);
            }
        });

        return myFragmentView;
    }

    /**
     * method for set driver button counter
     */
    public void setTripCount(int count) {
        if (count == 0) tripCount.setText("");
        else tripCount.setText(String.valueOf(count));
    }

    /**
     * navigate driver fragment
     * call home activity onResume
     */
    public void navigateDriver() {
        getFragmentManager().beginTransaction().replace(R.id.fragment, DriverFragment.newInstance()).commit();
    }


    @SuppressLint("MissingPermission")
    @Override
    public void onMapReady(GoogleMap googleMap) {
        final Permission permission = new Permission(getContext(), getActivity());
        gmap = googleMap;

        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                gmap.setMinZoomPreference(1);
                gmap.setMaxZoomPreference(20);
                if (!permission.isLocationPermissionGranted()) {
                    permission.checkPermissions();
                    return;
                }
                //gmap.setTrafficEnabled(true);
                gmap.setMyLocationEnabled(true);
                gmap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 16.0f));
                gmap.setOnMyLocationButtonClickListener(new GoogleMap.OnMyLocationButtonClickListener() {
                    @Override
                    public boolean onMyLocationButtonClick() {
                        gmap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 16.0f));
                        return false;
                    }
                });
            }
        });
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        Bundle mapViewBundle = outState.getBundle(MAP_VIEW_BUNDLE_KEY);
        if (mapViewBundle == null) {
            mapViewBundle = new Bundle();
            outState.putBundle(MAP_VIEW_BUNDLE_KEY, mapViewBundle);
        }

        mapView.onSaveInstanceState(mapViewBundle);
    }

    @Override
    public void onResume() {
        mapView.onResume();
        super.onResume();
    }

    @Override
    public void onStart() {
        mapView.onStart();
        super.onStart();
    }

    @Override
    public void onStop() {
        mapView.onStop();
        super.onStop();
    }

    @Override
    public void onPause() {
        mapView.onPause();
        super.onPause();
    }

    @Override
    public void onDestroy() {
        mapView.onDestroy();
        super.onDestroy();
    }

    @Override
    public void onLowMemory() {
        mapView.onLowMemory();
        super.onLowMemory();
    }
}
