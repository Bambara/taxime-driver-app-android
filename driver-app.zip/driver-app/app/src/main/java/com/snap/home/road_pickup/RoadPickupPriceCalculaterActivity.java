package com.snap.home.road_pickup;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;
import android.os.PowerManager;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.gson.Gson;
import com.snap.R;
import com.snap.background.LocationMonitoringService;
import com.snap.config.KeyString;
import com.snap.gps.GPSTracker;
import com.snap.model.DriverState;
import com.snap.model.roadPickupModel.EndRoadPickupTripModel;
import com.snap.model.roadPickupModel.StartRoadPickupTripResponceModel;
import com.snap.rest.ApiInterface;
import com.snap.rest.JsonApiClient;
import com.snap.session.LoginSession;
import com.snap.socket.MySocket;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RoadPickupPriceCalculaterActivity extends AppCompatActivity {
    public static final String START = "start";
    public static final String END = "end";
    public static final String BACK = "back";
    private TextView totalCost, waitingCost, waitingTime, distance;
    private Button startEndButton;
    private Handler handler = new Handler();
    private Runnable waitTimer, distanceTimer;
    //int longitude = -1, latitude = -1, counter = 0;
    private double lastLongitude, lastLatitude, waitTimeMillis = 0, totalTimeMillis = 0;
    double totalDistance = 0.0, prevDistance = 0.0, totalFare = 0.0, waitingFare = 0.0, waitedDistance = 0.0;
    private String buttonState = START;
    private StartRoadPickupTripResponceModel dataModel;
    private ProgressDialog progressDialog;
    private com.github.nkzawa.socketio.client.Socket mSocket;
    protected PowerManager.WakeLock mWakeLock;
    private double latitude, longitude;
    private String address;
    private EndRoadPickupTripModel.Location pickupLocation = new EndRoadPickupTripModel.Location();

    // Our handler for received Intents. This will be called whenever an Intent
// with an action named "custom-event-name" is broadcasted.
//    private BroadcastReceiver mMessageReceiver = new BroadcastReceiver() {
//        @Override
//        public void onReceive(Context context, Intent intent) {
//            // Get extra data included in the Intent
////            location.setLatitude(intent.getDoubleExtra(KeyString.EXTRA_LATITUDE, 0));
////            location.setLongitude(intent.getDoubleExtra(KeyString.EXTRA_LONGITUDE, 0));
////            location.setAddress(intent.getStringExtra(KeyString.EXTRA_ADDRESS));
//        }
//    };

    @SuppressLint("InvalidWakeLockTag")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_road_pickup_price_calculater);

        /* This code together with the one in onDestroy()
         * will make the screen be always on until this Activity gets destroyed. */
        final PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        this.mWakeLock = pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK, "My Tag");
        this.mWakeLock.acquire();

        // Register to receive messages.
        // We are registering an observer (mMessageReceiver) to receive Intents
        // with actions named "custom-event-name".
//        LocalBroadcastManager.getInstance(RoadPickupPriceCalculaterActivity.this).registerReceiver(mMessageReceiver, new IntentFilter(LocationMonitoringService.ACTION_LOCATION_BROADCAST));
//
        GPSTracker gpsTracker = new GPSTracker(getApplicationContext());
        address = gpsTracker.getAddressLine(getApplicationContext());
        latitude = gpsTracker.getLatitude();
        longitude = gpsTracker.getLongitude();

        LocalBroadcastManager.getInstance(RoadPickupPriceCalculaterActivity.this).registerReceiver(
                new BroadcastReceiver() {
                    @Override
                    public void onReceive(Context context, Intent intent) {
//                        latitude = intent.getDoubleExtra(KeyString.EXTRA_LATITUDE, 0);
//                        longitude = intent.getDoubleExtra(KeyString.EXTRA_LONGITUDE, 0);
//                        address = intent.getStringExtra(KeyString.EXTRA_ADDRESS);
                        latitude = intent.getDoubleExtra(KeyString.EXTRA_LATITUDE, 0);
                        longitude = intent.getDoubleExtra(KeyString.EXTRA_LONGITUDE, 0);
                        address = intent.getStringExtra(KeyString.EXTRA_ADDRESS);
                    }
                }, new IntentFilter(LocationMonitoringService.ACTION_LOCATION_BROADCAST)
        );

        Bundle bundle = getIntent().getExtras();
        String json = bundle.getString(KeyString.ROAD_PICUP_MODEL);
        Gson gson = new Gson();
        dataModel = gson.fromJson(json, StartRoadPickupTripResponceModel.class);

        MySocket socket = (MySocket)getApplication();
        mSocket = socket.getmSocket();

        totalCost = findViewById(R.id.total_cost);
        waitingCost = findViewById(R.id.waiting_cost);
        waitingTime = findViewById(R.id.wait_time);
        distance = findViewById(R.id.distance);
        startEndButton = findViewById(R.id.start_end_button);

        startEndButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View v) {
                final LoginSession session = new LoginSession(getApplicationContext());

                if (buttonState.equals(START)) {
                    AlertDialog alertDialog = new AlertDialog.Builder(RoadPickupPriceCalculaterActivity.this).create();
                    alertDialog.setTitle("Confirm trip START");
                    alertDialog.setMessage(" ");
                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "Yes",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    setCalculation(latitude, longitude);
                                    buttonState = END;
                                    v.setBackgroundResource(R.drawable.red_view_background_with_low_redious_conner);
                                    startEndButton.setText(R.string.end_trip);
                                    session.setDriverState(KeyString.ON_TRIP);
                                    GPSTracker location = new GPSTracker(getApplicationContext());
                                    pickupLocation.setAddress(location.getAddressLine(getApplicationContext()));
                                    pickupLocation.setLatitude(location.getLatitude());
                                    pickupLocation.setLongitude(location.getLongitude());
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "No",
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.show();
                }  else if (buttonState.equals(END)) {
                    AlertDialog alertDialog = new AlertDialog.Builder(RoadPickupPriceCalculaterActivity.this).create();
                    alertDialog.setTitle("Confirm trip END");
                    alertDialog.setMessage(" ");
                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "Yes",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    handler.removeCallbacks(distanceTimer);
                                    tripEndApiCall();
                                    session.setDriverState(KeyString.ONLINE);
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "No",
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.show();
                } else if (buttonState.equals(BACK)) {
                    onBackPressed();
                }
                DriverState state = new DriverState(mSocket.id(), session.getDriverState(), new LoginSession(getApplicationContext()).get_Id());
                try {
                    mSocket.emit(KeyString.UPDATE_DRIVER_STATE_SOCKET, new JSONObject(new Gson().toJson(state, DriverState.class)));
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

        });
    }

    @Override
    public void onDestroy() {
        this.mWakeLock.release();
        super.onDestroy();
    }

    /**
     * road pickup distance, time and cost calculator
     * @param pickupLongitude
     * @param pickupLatitude
     */
    private void setCalculation(final double pickupLatitude, final double pickupLongitude) {
        lastLongitude = pickupLongitude;
        lastLatitude = pickupLatitude;
        distanceTimer = new Runnable() {
            @Override
            public void run() {
//                GPSTracker location = new GPSTracker(getApplicationContext());
                totalTimeMillis = totalTimeMillis + 1000;

                if (getDistance(lastLatitude, lastLongitude, latitude, longitude) < 0.005) {
                    waitTimeMillis = waitTimeMillis + 1000;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            waitingTime.setText((int)(waitTimeMillis/60000) + "Min " + (int)(waitTimeMillis/1000)%60 + "S");
                        }
                    });
                    waitingFare = (waitTimeMillis/60000)*(dataModel.getContent().get(0).getNormalWaitingChargePerMinute());
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            waitingCost.setText(new DecimalFormat("00.00").format(waitingFare) + " Rs");
                        }
                    });
                }

                if (getDistance(lastLatitude, lastLongitude, latitude, longitude) < 10000) {
                    totalDistance = prevDistance + getDistance(lastLatitude, lastLongitude, latitude, longitude);
                    waitedDistance = totalDistance + totalDistance * 0.012;
                    lastLatitude = latitude;
                    lastLongitude = longitude;
                    prevDistance = totalDistance;
                }
//                if (latitude != 0 && longitude != 0) {
//                    if (getDistance(lastLatitude, lastLongitude, latitude, longitude) == 0) {
//                        waitTimeMillis = waitTimeMillis + 500;
//                        waitingTime.setText((int)(waitTimeMillis/60000) + "Min " + (int)(waitTimeMillis/1000)%60 + "S");
//                        waitingFare = (waitTimeMillis/60000)*(dataModel.getContent().get(0).getNormalWaitingChargePerMinute());
//                        waitingCost.setText(new DecimalFormat("00.00").format(waitingFare) + " Rs");
//                    }
//
//                    if (getDistance(lastLatitude, lastLongitude, latitude, longitude) < 10000) {
//                        totalDistance = prevDistance + getDistance(lastLatitude, lastLongitude, latitude, longitude);
//                        lastLatitude = latitude;
//                        lastLongitude = longitude;
//                        prevDistance = totalDistance;
//                    }

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            distance.setText(String.valueOf(round(waitedDistance/1000, 1)) + "Km");
                        }
                    });

                    if ((waitedDistance/1000) <= dataModel.getContent().get(0).getMinimumKM()) {
                        totalFare = dataModel.getContent().get(0).getBaseFare()
                                + dataModel.getContent().get(0).getMinimumFare()
                                + waitingFare;
                    } else if ((waitedDistance/1000) <= dataModel.getContent().get(0).getBelowAboveKMRange()) {
                        totalFare = dataModel.getContent().get(0).getBaseFare()
                                + dataModel.getContent().get(0).getMinimumFare()
                                + dataModel.getContent().get(0).getBelowKMFare()*((waitedDistance/1000) - dataModel.getContent().get(0).getMinimumKM())
                                + waitingFare;
                    } else if ((waitedDistance/1000) > dataModel.getContent().get(0).getBelowAboveKMRange()) {
                        totalFare = dataModel.getContent().get(0).getBaseFare()
                                + dataModel.getContent().get(0).getMinimumFare()
                                + dataModel.getContent().get(0).getBelowKMFare()*(dataModel.getContent().get(0).getBelowAboveKMRange() - dataModel.getContent().get(0).getMinimumKM())
                                + dataModel.getContent().get(0).getAboveKMFare()*((waitedDistance/1000) - dataModel.getContent().get(0).getBelowAboveKMRange())
                                + waitingFare;
                    }

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            totalCost.setText(new DecimalFormat("00.00").format(totalFare) + " Rs");
                        }
                    });
//                }

                handler.postDelayed(this, 1000);
            }
        };
        handler.postDelayed(distanceTimer, 1000);
    }

    /**
     * round double value with two floating point
     * @param value
     * @param places
     * @return
     */
    public double round(double value, int places) {
        if (places < 0) throw new IllegalArgumentException();

        long factor = (long) Math.pow(10, places);
        value = value * factor;
        long tmp = Math.round(value);
        return (double) tmp / factor;
    }

    /**
     * calculate air distance using given two location
     * @param prevLatitude
     * @param preLongitude
     * @param newLatitude
     * @param newLongitude
     * @return
     */
    private Double getDistance(double prevLatitude, double preLongitude, double newLatitude, double newLongitude) {
        android.location.Location loc1 = new android.location.Location("");
        loc1.setLatitude(prevLatitude);
        loc1.setLongitude(preLongitude);
        android.location.Location loc2 = new android.location.Location("");
        loc2.setLatitude(newLatitude);
        loc2.setLongitude(newLongitude);
        double distanceInMeters = loc1.distanceTo(loc2);
        return Math.abs(distanceInMeters);
    }

    /**
     * road pickup end api call
     */
    private void tripEndApiCall() {
//        GPSTracker location = new GPSTracker(getApplicationContext());
        EndRoadPickupTripModel dataModel = new EndRoadPickupTripModel();
        dataModel.setDistance(waitedDistance);
        dataModel.setTotalCost(totalFare);
        dataModel.setWaitTime(waitTimeMillis/1000);
        dataModel.setWaitingCost(waitingFare);
        dataModel.setId(this.dataModel.getTripId());
        EndRoadPickupTripModel.Location dropLocation = new EndRoadPickupTripModel.Location();
        dropLocation.setLatitude(latitude);
        dropLocation.setLongitude(longitude);
        dataModel.setDropLocation(dropLocation);
        dataModel.setPickupLocation(pickupLocation);
        dataModel.setAdminCommission(this.dataModel.getContent().get(0).getDistrictPrice());
        dataModel.setDriverId(new LoginSession(getApplicationContext()).getUserDetails().getContent().getId());
        dataModel.setPaymentMethod("cash");
        dataModel.setTripTime(String.valueOf(totalTimeMillis/60000));

        progressDialog = new ProgressDialog(RoadPickupPriceCalculaterActivity.this);
        progressDialog.setMessage("Loading...");
        progressDialog.show();

        ApiInterface apiInterface = JsonApiClient.getApiClient().create(ApiInterface.class);
        Call<ResponseBody> call = apiInterface.endRoadPickup(dataModel);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                progressDialog.dismiss();
                Log.i("TAG_RESPONSE_CODE", String.valueOf(response.code()));
                if (response.code() == 200) {
                    buttonState = BACK;
                    startEndButton.setBackgroundResource(R.drawable.green_view_background_with_low_redious_conner);
                    handler.removeCallbacks(distanceTimer);
                    startEndButton.setText(R.string.back_to_home);
                } else {
                    AlertDialog alertDialog = new AlertDialog.Builder(RoadPickupPriceCalculaterActivity.this).create();
                    alertDialog.setTitle("Something Went Wrong...");
                    alertDialog.setMessage("Place Check your Internet Connection and End again");
                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.show();
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                progressDialog.dismiss();
                Log.i("TAG_ONFAILURE", t.getMessage());
                AlertDialog alertDialog = new AlertDialog.Builder(RoadPickupPriceCalculaterActivity.this).create();
                alertDialog.setTitle("Something Went Wrong...");
                alertDialog.setMessage("Place Check your Internet Connection and End again");
                alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                alertDialog.show();
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (buttonState != END) {
            super.onBackPressed();
        } else {
            AlertDialog alertDialog = new AlertDialog.Builder(RoadPickupPriceCalculaterActivity.this).create();
            alertDialog.setTitle("Something Went Wrong...");
            alertDialog.setMessage("End Your Current Trip and Back again");
            alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
            alertDialog.show();
        }
    }
}
