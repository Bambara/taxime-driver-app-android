package com.snap.home.driver;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.snap.R;
import com.snap.adapters.TripAdapter;
import com.snap.home.HomeActivity;
import com.snap.model.tripModel.TripModel;

import java.util.ArrayList;
import java.util.List;

public class BookingsFragment extends Fragment {
    private RecyclerView recyclerView;
    List<TripModel> tripModelList = new ArrayList<>();
    TripAdapter adapter;
//    Handler handler = new Handler();
//    Runnable timerRunnable = new Runnable() {
//        @Override
//        public void run() {
//            synchronized(adapter){
//                adapter = new TripAdapter(getContext(), tripModelList);
//                recyclerView.setAdapter(adapter);
//            }
//            handler.postDelayed(this, 200);
//        }
//    };

    public static BookingsFragment newInstance() {
        BookingsFragment fragment = new BookingsFragment();
        return fragment;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        tripModelList = ((HomeActivity)getActivity()).tripModelList;
        Log.i("TAG_BOOKING_FRAGMENT", "call onAttach method");
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Log.i("TAG_BOOKING_FRAGMENT", "call onCreate method");
    }

    @SuppressLint("ResourceAsColor")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View myFragmentView =  inflater.inflate(R.layout.fragment_bookings, container, false);

        Log.i("TAG_BOOKING_FRAGMENT", "call onCreateView method");
        recyclerView = myFragmentView.findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(recyclerView.getContext(), LinearLayoutManager.VERTICAL,false));
        recyclerView.setHasFixedSize(true);
//        adapter = new TripAdapter(getContext(), tripModelList);
//        recyclerView.setAdapter(adapter);
        if (!tripModelList.isEmpty()) {
            adapter = new TripAdapter(getContext(), tripModelList);
            recyclerView.setAdapter(adapter);
            //handler.postDelayed(timerRunnable, 0);
        }

        return myFragmentView;
    }

    public void updateList(List<TripModel> data) {
        this.tripModelList = data;
        if (adapter != null) {
            adapter.notifyDataSetChanged();
            //handler.postDelayed(timerRunnable, 0);
            Log.i("TAG_UPDATE_LIST", "adapter not null");
        } else {
            adapter = new TripAdapter(getContext(), tripModelList);
            recyclerView.setAdapter(adapter);
            //handler.postDelayed(timerRunnable, 0);
            Log.i("TAG_UPDATE_LIST", "null adapter");
        }
    }

}
