package com.snap.home.dispatcher;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Build;
import android.os.Vibrator;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.location.places.AutocompleteFilter;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.PlaceBuffer;
import com.google.android.gms.location.places.Places;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.snap.R;
import com.snap.adapters.PlaceArrayAdapter;
import com.snap.adapters.CategoryAdapter;
import com.snap.config.KeyString;
import com.snap.config.Permission;
import com.snap.config.SoftKeyboard;
import com.snap.gps.GPSTracker;
import com.snap.model.dispatchModel.DispatchModel;
import com.snap.model.dispatchModel.Location;
import com.snap.model.mapDistanceModel.MapDistanceModel;
import com.snap.model.vehicalCategoryModel.VehicleCategoryRequestModel;
import com.snap.model.vehicalCategoryModel.VehicleCategoryResponseModel;
import com.snap.rest.ApiInterface;
import com.snap.rest.JsonApiClient;
import com.snap.rest.mapApiClient;
import com.snap.session.LoginSession;
import com.snap.validation.Formvalidation;
import android.view.ViewGroup.LayoutParams;

import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DispatcherFormActivity extends AppCompatActivity implements OnMapReadyCallback, GoogleApiClient.OnConnectionFailedListener, GoogleApiClient.ConnectionCallbacks, CategoryAdapter.SingleClickListener {
    private static final String MAP_VIEW_BUNDLE_KEY = "MapViewBundleKey";
    private ProgressDialog progressDialog;
    private GoogleMap gmap;
    private MapView mapView;
    private List<Marker> markers = new ArrayList<>();
    private CardView mapCard;
    private GPSTracker location;
    LatLng latLng, pickupLatLng = null, dropLatLng= null;
    Polyline line;
    CategoryAdapter categoryAdapter;
    RecyclerView recyclerView;
    LinearLayoutManager linearLayoutManager;
    private int mYear, mMonth, mDay;
    private ConstraintLayout backButton;
    private EditText name, mobileNumber;
    private ImageView nameError, mobileNumberError, pickupLocationError, dropLocationError, passengerMinusButton, passengerPlusButton, costMinusButton, costPlusButton, mapOverLayer;
    private TextView numberOfPassenger, unitCost, totalCost, time, date, distance, nots, categoryName;
    private int hr, min;
    private AutoCompleteTextView pickupLocation, dropLocation;
    private GoogleApiClient mGoogleApiClient;
    private PlaceArrayAdapter mPlaceArrayAdapter;
    private ScrollView scrollView;
    private DispatchModel dispatchModel;
    private VehicleCategoryResponseModel vehicleCategoryList;
    private VehicleCategoryResponseModel.Content selectedVehicleCategory;
    private CalendarView calenderView;
    private Button orderButton;
    private LinearLayout header;
    private static final int GOOGLE_API_CLIENT_ID = R.string.google_android_map_api_key;
    private static final LatLngBounds BOUNDS_MOUNTAIN_VIEW = new LatLngBounds(new LatLng(37.398160, -122.180831), new LatLng(37.430610, -121.972090));
    private int selectedCategoryPosition = 0;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dispatcher_form);

        findViewById(R.id.root_layout).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                SoftKeyboard.hideSoftKeyboard(DispatcherFormActivity.this);
                return false;
            }
        });

        dispatchModel = new DispatchModel(); //dispatch data model
        dispatchModel.setNomberOfPassengers(1);
        dispatchModel.setType(KeyString.TYPE);
        dispatchModel.setDispatcherId(new LoginSession(getApplicationContext()).getUserDetails().getContent().getId());

        pickupLocationError = findViewById(R.id.pickup_location_error);
        dropLocationError = findViewById(R.id.drop_location_error);
        distance = findViewById(R.id.distance);
        totalCost = findViewById(R.id.total_cost);
        nots = findViewById(R.id.notes);
        scrollView = findViewById(R.id.custom_scrollview);
        orderButton = findViewById(R.id.order_button);
        orderButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dispatchModel.setNotes(nots.getText().toString());
                if (formValidate()) addDispatch();
                else Toast.makeText(getApplicationContext(),"Fill all the required fields", Toast.LENGTH_SHORT).show();
            }
        });

        location = new GPSTracker(getApplicationContext());
        latLng = new LatLng(location.getLatitude(), location.getLongitude());
        Bundle mapViewBundle = null;
        if (savedInstanceState != null) {
            mapViewBundle = savedInstanceState.getBundle(MAP_VIEW_BUNDLE_KEY);
        }
        mapView = findViewById(R.id.map_view);
        mapView.onCreate(mapViewBundle);
        mapView.getMapAsync(this);

        mapOverLayer = findViewById(R.id.map_over_layer);
        mapOverLayer.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                int action = event.getAction();
                switch (action) {
                    case MotionEvent.ACTION_DOWN:
                        // Disallow ScrollView to intercept touch events.
                        scrollView.requestDisallowInterceptTouchEvent(true);
                        // Disable touch on transparent view
                        return false;

                    case MotionEvent.ACTION_UP:
                        // Allow ScrollView to intercept touch events.
                        scrollView.requestDisallowInterceptTouchEvent(false);
                        return true;

                    case MotionEvent.ACTION_MOVE:
                        scrollView.requestDisallowInterceptTouchEvent(true);
                        return false;

                    default:
                        return true;
                }
            }
        });

        backButton = findViewById(R.id.back_button);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        header = findViewById(R.id.header);
        final View activityRootView = findViewById(R.id.root_layout);
        activityRootView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                int heightDiff = activityRootView.getRootView().getHeight() - activityRootView.getHeight();
                if (heightDiff > dpToPx(DispatcherFormActivity.this, 200)) { // if more than 200 dp, it's probably a keyboard...
                    header.setVisibility(View.GONE);
                } else {
                      header.setVisibility(View.VISIBLE);
                }
            }
        });

        formEditTextChecker();
        setNumberOfPassenger();
        setTime();
        setDate();
        setAutocompleteView();
        getCategory();
    }


    /**
     * popup method
     */
    private void popup(String message, String buttonText, boolean state, final int responce) {

        // Get the widgets reference from XML layout
        LinearLayout linearLayout = findViewById(R.id.root_layout);

        // Initialize a new instance of LayoutInflater service
        LayoutInflater inflater = (LayoutInflater) getApplicationContext().getSystemService(LAYOUT_INFLATER_SERVICE);

        // Inflate the custom layout/view
        View customView = inflater.inflate(R.layout.singale_button_popup,null);

        /*
            public PopupWindow (View contentView, int width, int height)
                Create a new non focusable popup window which can display the contentView.
                The dimension of the window must be passed to this constructor.

                The popup does not provide any background. This should be handled by
                the content view.

            Parameters
                contentView : the popup's content
                width : the popup's width
                height : the popup's height
        */
        // Initialize a new instance of popup window
        final PopupWindow mPopupWindow = new PopupWindow(customView, LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
        mPopupWindow.setOutsideTouchable(false);

        // Set an elevation value for popup window
        // Call requires API level 21
        if(Build.VERSION.SDK_INT >= 21){
            mPopupWindow.setElevation(5.0f);
        }

        // Get a reference for the custom view close button
        TextView popupMessage = customView.findViewById(R.id.popup_message);
        ImageView popupImage = customView.findViewById(R.id.popup_image);
        Button popupButton = customView.findViewById(R.id.popup_button);

        popupMessage.setText(message);
        if (state) popupImage.setImageResource(R.drawable.right_icon);
        else popupImage.setImageResource(R.drawable.wrong_icon);

        popupButton.setText(buttonText);
        popupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (responce) {
                    case 200:
                        finish();
                        mPopupWindow.dismiss();
                        break;
                    case 202:
                        mPopupWindow.dismiss();
                        break;
                    case 203:
                        finish();
                        mPopupWindow.dismiss();
                        break;
                    default:
                        finish();
                        mPopupWindow.dismiss();
                        break;
                }
            }
        });

        /*
            public void showAtLocation (View parent, int gravity, int x, int y)
                Display the content view in a popup window at the specified location. If the
                popup window cannot fit on screen, it will be clipped.
                Learn WindowManager.LayoutParams for more information on how gravity and the x
                and y parameters are related. Specifying a gravity of NO_GRAVITY is similar
                to specifying Gravity.LEFT | Gravity.TOP.

            Parameters
                parent : a parent view to get the getWindowToken() token from
                gravity : the gravity which controls the placement of the popup window
                x : the popup's x location offset
                y : the popup's y location offset
        */
        // Finally, show the popup window at the center location of root relative layout
        mPopupWindow.showAtLocation(linearLayout, Gravity.CENTER,0,0);
    }

    /**
     * dispatch api call
     */
    private void addDispatch() {
        progressDialog = new ProgressDialog(DispatcherFormActivity.this);
        progressDialog.setMessage("Loading...");
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();
        ApiInterface apiInterface = JsonApiClient.getApiClient().create(ApiInterface.class);
        Call<ResponseBody> call = apiInterface.addDispatch(dispatchModel);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                progressDialog.dismiss();
                if (response.code() == 200) {
                    popup(getResources().getString(R.string.almost_done), getResources().getString(R.string.done), true, 200);
                } else if (response.code() == 202) {
                    popup(getResources().getString(R.string.no_online_drivers_in_pick), getResources().getString(R.string.cancel), false, 202);
                } else if (response.code() == 203) {
                    popup(getResources().getString(R.string.no_online_drivers), getResources().getString(R.string.cancel), false, 203);
                } else {
                    popup(getResources().getString(R.string.unexpected_error), getResources().getString(R.string.cancel), false, 0);
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                progressDialog.dismiss();
                popup(getResources().getString(R.string.unexpected_error), getResources().getString(R.string.cancel), false, 0);
            }
        });
    }

    /**
     * dispatch form validation method
     */
    private boolean formValidate() {

        boolean state = true;
        if (dispatchModel.getCustomerName() == null ? true : !Formvalidation.isName(dispatchModel.getCustomerName())) {
            nameError.setImageResource(R.drawable.wrong_icon);
            state = false;
        }
        if (dispatchModel.getMobileNumber() == null ? true : !Formvalidation.isMobileNumber(dispatchModel.getMobileNumber())) {
            mobileNumberError.setImageResource(R.drawable.wrong_icon);
            state = false;
        }
        if (dispatchModel.getPickupLocation() == null) {
            pickupLocationError.setImageResource(R.drawable.wrong_icon);
            state = false;
        }
        if (dispatchModel.getDropLocations() == null) {
            dropLocationError.setImageResource(R.drawable.wrong_icon);
            state = false;
        }
        if (dispatchModel.getVehicleCategory() == null && dispatchModel.getVehicleSubCategory() == null) {
            state = false;
        }
        return state;
    }

    /**
     *method for get all category using pickup time and location
     */
    private void getCategory() {
        progressDialog = new ProgressDialog(DispatcherFormActivity.this);
        progressDialog.setMessage("Loading...");
        progressDialog.show();
        GPSTracker gpsTracker = new GPSTracker(getApplicationContext());

        VehicleCategoryRequestModel requestModel = new VehicleCategoryRequestModel();
        if (dispatchModel.getPickupLocation() == null) {
            requestModel.setAddress(gpsTracker.getAddressLine(getApplicationContext()));
            requestModel.setLatitude(gpsTracker.getLatitude());
            requestModel.setLongitude(gpsTracker.getLongitude());
        } else {
            requestModel.setAddress(dispatchModel.getPickupLocation().getAddress());
            requestModel.setLatitude(dispatchModel.getPickupLocation().getLatitude());
            requestModel.setLongitude(dispatchModel.getPickupLocation().getLongitude());
            requestModel.setDate(dispatchModel.getPickupDate());
            requestModel.setTime(dispatchModel.getPickupTime());
        }

        ApiInterface apiInterface = JsonApiClient.getApiClient().create(ApiInterface.class);
        Call<VehicleCategoryResponseModel> call = apiInterface.getVehicleCategory(requestModel);
        call.enqueue(new Callback<VehicleCategoryResponseModel>() {
            @Override
            public void onResponse(Call<VehicleCategoryResponseModel> call, Response<VehicleCategoryResponseModel> response) {
                progressDialog.dismiss();
                Log.i("TAG_RESPONSE_CODE", String.valueOf(response.code()));
                if (response.code() == 200) {
                    vehicleCategoryList = response.body();
                    if (response.body().getContent().size() == 0) {
                        popup(getResources().getString(R.string.unexpected_error), getResources().getString(R.string.cancel), false, 0);
                        return;
                    }
                    setCategory(response.body());
                } else {
                    popup(getResources().getString(R.string.unexpected_error), getResources().getString(R.string.cancel), false, 0);
                }

            }

            @Override
            public void onFailure(Call<VehicleCategoryResponseModel> call, Throwable t) {
                progressDialog.dismiss();
                Log.i("TAG_ONFAILURE", t.getMessage());
                popup(getResources().getString(R.string.unexpected_error), getResources().getString(R.string.cancel), false, 0);
            }
        });
    }

    /**
     * set category and subcategory view
     */
    private void setCategory(VehicleCategoryResponseModel category) {

        setUnitCost(category);
        recyclerView = findViewById(R.id.category_recyclerview);
        categoryName = findViewById(R.id.category_name);

        linearLayoutManager = new LinearLayoutManager(recyclerView.getContext(), LinearLayoutManager.HORIZONTAL,false);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setHasFixedSize(true);
        category.setUnitCost(category.getContent().get(0).getLowerBidLimit());
        categoryAdapter = new CategoryAdapter(getApplicationContext(), category, 0);
        recyclerView.setAdapter(categoryAdapter);
        categoryAdapter.setOnItemClickListener(this);

        categoryName.setText(category.getContent().get(0).getCategoryTag());
        dispatchModel.setVehicleCategory(category.getContent().get(0).getCategoryTag());
        dispatchModel.setVehicleSubCategory(category.getContent().get(0).getSubCategoryName());
        dispatchModel.setUnitCost(category.getContent().get(0).getLowerBidLimit());
        selectedVehicleCategory = vehicleCategoryList.getContent().get(0);
        unitCost.setText("Rs. " + String.valueOf(category.getContent().get(0).getLowerBidLimit()) + " per Km");
        dispatchModel.setTotalCost((double)priceCalculation());
        dispatchModel.setValidTime(category.getContent().get(0).getValidTime());
        dispatchModel.setOperationRadius(category.getContent().get(0).getPriceSelection().get(0).getTimeBase().get(0).getRadius());
        //recyclerView.getLayoutManager().scrollToPosition(4);
    }
    public static Bitmap getBitmapFromURL(String src) {
        try {
            URL url = new URL(src);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.connect();
            InputStream input = connection.getInputStream();
            Bitmap myBitmap = BitmapFactory.decodeStream(input);
            return myBitmap;
        } catch (IOException e) {
            Log.i("TAG_IMAGE_BITMAP", e.toString());
            return null;
        }
    }
    @Override
    public void onItemClickListener(int position, List<VehicleCategoryResponseModel.Content> categories) {
        categoryAdapter.selectedItem(categories.get(position).getLowerBidLimit());
        categoryName.setText(categories.get(position).getCategoryTag());
        dispatchModel.setVehicleCategory(categories.get(position).getCategoryTag());
        dispatchModel.setVehicleSubCategory(categories.get(position).getSubCategoryName());
        dispatchModel.setUnitCost(categories.get(position).getLowerBidLimit());
        dispatchModel.setValidTime(categories.get(position).getValidTime());
        dispatchModel.setOperationRadius(categories.get(position).getPriceSelection().get(0).getTimeBase().get(0).getRadius());
        selectedVehicleCategory = vehicleCategoryList.getContent().get(position);
        unitCost.setText("Rs. " + String.valueOf(categories.get(position).getLowerBidLimit()) + " per Km");
        selectedCategoryPosition = position;
        //recyclerView.smoothScrollToPosition(linearLayoutManager.findFirstVisibleItemPosition() + 1);
        recyclerView.smoothScrollToPosition(position);
        priceCalculation();
    }

    /**
     * pickup location and drop location autocomplete view setup method
     */
    private void setAutocompleteView() {
        mGoogleApiClient = new GoogleApiClient.Builder(DispatcherFormActivity.this).addApi(Places.GEO_DATA_API).enableAutoManage(this, GOOGLE_API_CLIENT_ID, this).addConnectionCallbacks(this).build();
        pickupLocation = findViewById(R.id.picup_location);
        dropLocation = findViewById(R.id.drop_address);
        pickupLocation.setThreshold(3);    //minimum number of searching characters
        dropLocation.setThreshold(3);
        pickupLocation.setOnItemClickListener(pickupLocationClickListener);
        dropLocation.setOnItemClickListener(dropLocationClickListener);
        AutocompleteFilter typeFilter = new AutocompleteFilter.Builder().setCountry("LK").build();
        mPlaceArrayAdapter = new PlaceArrayAdapter(this, android.R.layout.simple_list_item_1, BOUNDS_MOUNTAIN_VIEW, typeFilter);
        pickupLocation.setAdapter(mPlaceArrayAdapter);
        dropLocation.setAdapter(mPlaceArrayAdapter);
    }
    private AdapterView.OnItemClickListener pickupLocationClickListener = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            final PlaceArrayAdapter.PlaceAutocomplete item = mPlaceArrayAdapter.getItem(position);
            final String placeId = String.valueOf(item.placeId);
            Log.i("LOG_TAG", "Selected: " + item.description);
            PendingResult<PlaceBuffer> placeResult = Places.GeoDataApi.getPlaceById(mGoogleApiClient, placeId);
            placeResult.setResultCallback(pickupPlaceDetailsCallback);
            Log.i("LOG_TAG", "Fetching details for ID: " + item.placeId);
        }
    };
    private ResultCallback<PlaceBuffer> pickupPlaceDetailsCallback = new ResultCallback<PlaceBuffer>() {
        @Override
        public void onResult(PlaceBuffer places) {
            if (!places.getStatus().isSuccess()) {
                Log.e("LOG_TAG", "Place query did not complete. Error: " + places.getStatus().toString());
                return;
            }
            // Selecting the first object buffer.
            final Place place = places.get(0);
            CharSequence attributions = places.getAttributions();

            pickupLatLng = place.getLatLng();
            gmap.clear();
            try {
                if (dropLatLng != null) markers.add(1, gmap.addMarker(new MarkerOptions().position(dropLatLng)));
            } catch (Exception e) {}
            try {
                if (pickupLatLng != null) markers.add(0, gmap.addMarker(new MarkerOptions().position(pickupLatLng)));
            } catch (Exception e) {}
            try {
                if (pickupLatLng != null && dropLatLng != null)  mapRoute(pickupLatLng, dropLatLng);
            } catch (Exception e) {}



//            mNameTextView.setText(Html.fromHtml(place.getName() + ""));
//            mAddressTextView.setText(Html.fromHtml(place.getAddress() + ""));
//            mIdTextView.setText(Html.fromHtml(place.getId() + ""));
//            mPhoneTextView.setText(Html.fromHtml(place.getPhoneNumber() + ""));
//            mWebTextView.setText(place.getWebsiteUri() + "");
            if (attributions != null) {
                //mAttTextView.setText(Html.fromHtml(attributions.toString()));
            }
        }
    };
    private AdapterView.OnItemClickListener dropLocationClickListener = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            final PlaceArrayAdapter.PlaceAutocomplete item = mPlaceArrayAdapter.getItem(position);
            final String placeId = String.valueOf(item.placeId);
            Log.i("LOG_TAG", "Selected: " + item.description);
            PendingResult<PlaceBuffer> placeResult = Places.GeoDataApi.getPlaceById(mGoogleApiClient, placeId);
            placeResult.setResultCallback(dropPlaceDetailsCallback);
            Log.i("LOG_TAG", "Fetching details for ID: " + item.placeId);
        }
    };
    private ResultCallback<PlaceBuffer> dropPlaceDetailsCallback = new ResultCallback<PlaceBuffer>() {
        @Override
        public void onResult(PlaceBuffer places) {
            if (!places.getStatus().isSuccess()) {
                Log.e("LOG_TAG", "Place query did not complete. Error: " + places.getStatus().toString());
                return;
            }
            // Selecting the first object buffer.
            final Place place = places.get(0);
            CharSequence attributions = places.getAttributions();

            dropLatLng = place.getLatLng();
            gmap.clear();
            try {
                if (dropLatLng != null) markers.add(1, gmap.addMarker(new MarkerOptions().position(dropLatLng)));
            } catch (Exception e) {}
            try {
                if (pickupLatLng != null) markers.add(0, gmap.addMarker(new MarkerOptions().position(pickupLatLng)));
            } catch (Exception e) {}
            try {
                if (pickupLatLng != null && dropLatLng != null)  mapRoute(pickupLatLng, dropLatLng);
            } catch (Exception e) {}

//            mNameTextView.setText(Html.fromHtml(place.getName() + ""));
//            mAddressTextView.setText(Html.fromHtml(place.getAddress() + ""));
//            mIdTextView.setText(Html.fromHtml(place.getId() + ""));
//            mPhoneTextView.setText(Html.fromHtml(place.getPhoneNumber() + ""));
//            mWebTextView.setText(place.getWebsiteUri() + "");
            if (attributions != null) {
                //mAttTextView.setText(Html.fromHtml(attributions.toString()));
            }
        }
    };

    @Override
    public void onConnected(Bundle bundle) {
        mPlaceArrayAdapter.setGoogleApiClient(mGoogleApiClient);
        Log.i("LOG_TAG", "Google Places API connected.");

    }

    @Override
    public void onConnectionFailed(ConnectionResult connectionResult) {
        Log.e("LOG_TAG", "Google Places API connection failed with error code: " + connectionResult.getErrorCode());
        //Toast.makeText(this, "Google Places API connection failed with error code:" + connectionResult.getErrorCode(), Toast.LENGTH_LONG).show();
    }

    @Override
    public void onConnectionSuspended(int i) {
        mPlaceArrayAdapter.setGoogleApiClient(null);
        Log.e("LOG_TAG", "Google Places API connection suspended.");
    }

    /**
     * map path api call
     */
    private void mapRoute(final LatLng origin, LatLng dest) {

        ApiInterface apiInterface = mapApiClient.getApiClient().create(ApiInterface.class);
        Call<MapDistanceModel> call = apiInterface.getDistanceDuration("metric", origin.latitude + "," + origin.longitude,dest.latitude + "," + dest.longitude, "driving");
        call.enqueue(new Callback<MapDistanceModel>() {
            @Override
            public void onResponse(Call<MapDistanceModel> call, Response<MapDistanceModel> response) {

                try {
                    //Remove previous line from map
                    if (line != null) {
                        line.remove();
                    }
                    // This loop will go through all the results and add marker on each location.
                    for (int i = 0; i < response.body().getRoutes().size(); i++) {
                        String dist = response.body().getRoutes().get(i).getLegs().get(i).getDistance().getText();
                        String time = response.body().getRoutes().get(i).getLegs().get(i).getDuration().getText();
                        distance.setText(dist);
                        String encodedString = response.body().getRoutes().get(0).getOverviewPolyline().getPoints();
                        List<LatLng> list = decodePoly(encodedString);
                        line = gmap.addPolyline(new PolylineOptions().addAll(list).width(10).color(Color.RED).geodesic(true));
                        Location pickupLocation = new Location(response.body().getRoutes().get(0).getLegs().get(0).getPickupAddress(),
                                response.body().getRoutes().get(0).getLegs().get(0).getPickupLocation().getLat(),
                                response.body().getRoutes().get(0).getLegs().get(0).getPickupLocation().getLng());
                        dispatchModel.setPickupLocation(pickupLocation);
                        Location dropLocation = new Location(response.body().getRoutes().get(0).getLegs().get(0).getDropAddress(),
                                response.body().getRoutes().get(0).getLegs().get(0).getDropLocation().getLat(),
                                response.body().getRoutes().get(0).getLegs().get(0).getDropLocation().getLng());
                        List<Location> dropLocationList = new ArrayList<>();
                        dropLocationList.add(dropLocation);
                        dispatchModel.setDropLocations(dropLocationList);
                        dispatchModel.setDistance(response.body().getRoutes().get(0).getLegs().get(0).getDistance().getValue()/1000);
                    }
                    getCategory();
//                    gmap.moveCamera(CameraUpdateFactory.newLatLng(origin));
//                    gmap.animateCamera(CameraUpdateFactory.zoomTo(11));
                    pickupLocationError.setImageResource(R.drawable.right_icon);
                    dropLocationError.setImageResource(R.drawable.right_icon);
                    //totalCost.setText("Rs. " + String.valueOf(round(dispatchModel.getTotalCost(), 2)));

                    LatLngBounds.Builder builder = new LatLngBounds.Builder();
                    Log.i("TAG_MARKE1", String.valueOf(markers.get(0).getPosition().latitude));
                    Log.i("TAG_MARKE2", String.valueOf(markers.get(1).getPosition().latitude));
                    for (Marker marker : markers) {
                        builder.include(marker.getPosition());
                    }
                    LatLngBounds bounds = builder.build();
                    CameraUpdate cu = CameraUpdateFactory.newLatLngBounds(bounds, (int)dpToPx(DispatcherFormActivity.this, 32));
                    gmap.animateCamera(cu);

                } catch (Exception e) {
                    Log.d("onResponse", "There is an error");
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<MapDistanceModel> call, Throwable t) {
                Log.d("onFailure", t.toString());
            }
        });

    }
    private List<LatLng> decodePoly(String encoded) {
        List<LatLng> poly = new ArrayList<LatLng>();
        int index = 0, len = encoded.length();
        int lat = 0, lng = 0;

        while (index < len) {
            int b, shift = 0, result = 0;
            do {
                b = encoded.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlat = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lat += dlat;

            shift = 0;
            result = 0;
            do {
                b = encoded.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlng = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lng += dlng;

            LatLng p = new LatLng( (((double) lat / 1E5)),
                    (((double) lng / 1E5) ));
            poly.add(p);
        }

        return poly;
    }


    /**
     * method for set time
     */
    private void setTime() {
        time = findViewById(R.id.time);
        int  hours = new Time(System.currentTimeMillis()).getHours();
        int minutes = new Time(System.currentTimeMillis()).getMinutes();
        Serializable sHr = hours < 10 ? "0"+hours : hours;
        Serializable sMin = minutes < 10 ? "0"+minutes : minutes;
        dispatchModel.setPickupTime(sHr + ":" + sMin + ":00");
        updateTime(hours, minutes);
        time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new TimePickerDialog(DispatcherFormActivity.this, timePickerListener, hr, min, false).show();
            }
        });
    }
    private TimePickerDialog.OnTimeSetListener timePickerListener = new TimePickerDialog.OnTimeSetListener() {
        @Override
        public void onTimeSet(TimePicker view, int hourOfDay, int minutes) {
            // TODO Auto-generated method stub
            hr = hourOfDay;
            min = minutes;
            Serializable sHr = hourOfDay < 10 ? "0"+hourOfDay : hourOfDay;
            Serializable sMin = minutes < 10 ? "0"+minutes : minutes;
            dispatchModel.setPickupTime(sHr + ":" + sMin + ":00");
            if (dispatchModel.getPickupLocation() != null) {
                getCategory();
            }
            updateTime(hr, min);
            Log.i("TAG_TIME", dispatchModel.getPickupTime());

        }
    };
//    private static String utilTime(int value) {
//        if (value < 10) return "0" + String.valueOf(value);
//        else return String.valueOf(value);
//    }
    private void updateTime(int hours, int mins) {
        String timeSet = "";
        if (hours > 12) {
            hours -= 12;
            timeSet = "PM";
        } else if (hours == 0) {
            hours += 12;
            timeSet = "AM";
        } else if (hours == 12) timeSet = "PM";
        else timeSet = "AM";
        String minutes = "";
        if (mins < 10) minutes = "0" + mins;
        else minutes = String.valueOf(mins);
        String aTime = new StringBuilder().append(hours).append(':').append(minutes).append(" ").append(timeSet).toString();
        time.setText(aTime);
    }

    /**
     * method for the set calenderView
     */
    private void setDate() {
        date = findViewById(R.id.date);

        // Get Current Date
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);

        Serializable sMonth = (mMonth + 1) < 10 ? "0" + (mMonth + 1) : (mMonth + 1);
        Serializable sDay = mDay < 10 ? "0" + mDay : mDay;

        date.setText(mYear + "-" + sMonth + "-" + sDay);
        dispatchModel.setPickupDate(mYear + "-" + sMonth + "-" + sDay);

        date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(DispatcherFormActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        Serializable sMonth = (monthOfYear + 1) < 10 ? "0" + (monthOfYear + 1) : (monthOfYear + 1);
                        Serializable sDay = dayOfMonth < 10 ? "0" + dayOfMonth : dayOfMonth;
                        date.setText(year + "-" + sMonth + "-" + sDay);
                        dispatchModel.setPickupDate(year + "-" + sMonth + "-" + sDay);
                        //date = String.valueOf(dayOfMonth) + "/" + String.valueOf(monthOfYear + 1) + "/" + String.valueOf(year);
                    }
                }, mYear, mMonth, mDay);
                datePickerDialog.show();
            }
        });
    }

    /**
     * validate the text input when text changed
     */
    private boolean formEditTextChecker() {
        nameError = findViewById(R.id.name_error);
        mobileNumberError = findViewById(R.id.mobile_number_error);
        name = findViewById(R.id.name);
        name.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (Formvalidation.isName(s.toString())) {
                    nameError.setImageResource(R.drawable.right_icon);
                    dispatchModel.setCustomerName(s.toString());
                }
                else nameError.setImageResource(R.drawable.wrong_icon);
            }
        });
        mobileNumber = findViewById(R.id.mobile_number);
        mobileNumber.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (Formvalidation.isMobileNumber(s.toString())) {
                    mobileNumberError.setImageResource(R.drawable.right_icon);
                    dispatchModel.setMobileNumber(s.toString());
                }
                else mobileNumberError.setImageResource(R.drawable.wrong_icon);
            }
        });

        if (nameError.getDrawable() == getDrawable(R.drawable.right_icon) && mobileNumberError.getDrawable() == getDrawable(R.drawable.right_icon)) return true;
        else return false;
    }

    /**
     * method for the set number of passengers
     */
    private void setNumberOfPassenger() {
        final Vibrator vibe = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        passengerMinusButton = findViewById(R.id.passenger_minus_button);
        passengerPlusButton = findViewById(R.id.passenger_plus_button);
        numberOfPassenger = findViewById(R.id.number_of_passenger);

        passengerPlusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                vibe.vibrate(40);
                int count = Integer.parseInt(numberOfPassenger.getText().toString());
                count++;
                numberOfPassenger.setText(String.valueOf(count));
                dispatchModel.setNomberOfPassengers(count);
            }
        });
        passengerMinusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                vibe.vibrate(40);
                int count = Integer.parseInt(numberOfPassenger.getText().toString());
                if (count > 1) count--;
                numberOfPassenger.setText(String.valueOf(count));
                dispatchModel.setNomberOfPassengers(count);
            }
        });
    }

    /**
     * method for the set unit cost
     */
    private void setUnitCost(final VehicleCategoryResponseModel categories) {
        final Vibrator vibe = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        costMinusButton = findViewById(R.id.cost_minus_button);
        costPlusButton = findViewById(R.id.cost_plus_button);
        unitCost = findViewById(R.id.unit_cost);
        unitCost.setText("Rs. " + String.valueOf(dispatchModel.getUnitCost()) + " per Km");

        costPlusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                vibe.vibrate(40);
                int count = dispatchModel.getUnitCost();
                if (count < categories.getContent().get(selectedCategoryPosition).getUpperBidLimit()) count++;
                dispatchModel.setUnitCost(count);
                unitCost.setText("Rs. " + String.valueOf(count) + " per Km");
                categoryAdapter.categoryEnable(count);
                dispatchModel.setTotalCost((double)priceCalculation());
            }
        });
        costMinusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                vibe.vibrate(40);
                int count = dispatchModel.getUnitCost();
                if (count > categories.getContent().get(selectedCategoryPosition).getLowerBidLimit()) count--;
                dispatchModel.setUnitCost(count);
                unitCost.setText("Rs. " + String.valueOf(count) + " per Km");
                categoryAdapter.categoryEnable(count);
                dispatchModel.setTotalCost((double)priceCalculation());
            }
        });
    }

    /**
     * price calculation method
     */
    private int priceCalculation() {
        int totalCost = 0;
        if (vehicleCategoryList == null || dispatchModel.getDistance() == 0.0f) return 0;
        if (dispatchModel.getDistance() <= selectedVehicleCategory.getPriceSelection().get(0).getTimeBase().get(0).getMinimumKM()) {
            totalCost = (int)(selectedVehicleCategory.getPriceSelection().get(0).getTimeBase().get(0).getBaseFare()
                                + selectedVehicleCategory.getPriceSelection().get(0).getTimeBase().get(0).getMinimumFare());
        } else if (dispatchModel.getDistance() <= selectedVehicleCategory.getPriceSelection().get(0).getTimeBase().get(0).getBelowAboveKMRange()) {
            totalCost = (int)(selectedVehicleCategory.getPriceSelection().get(0).getTimeBase().get(0).getBaseFare()
                                + selectedVehicleCategory.getPriceSelection().get(0).getTimeBase().get(0).getMinimumFare()
                                + (dispatchModel.getDistance() - selectedVehicleCategory.getPriceSelection().get(0).getTimeBase().get(0).getMinimumKM()) * dispatchModel.getUnitCost());
        } else if (dispatchModel.getDistance() > selectedVehicleCategory.getPriceSelection().get(0).getTimeBase().get(0).getBelowAboveKMRange()) {
            totalCost = (int)(selectedVehicleCategory.getPriceSelection().get(0).getTimeBase().get(0).getBaseFare()
                                + selectedVehicleCategory.getPriceSelection().get(0).getTimeBase().get(0).getMinimumFare()
                                + (selectedVehicleCategory.getPriceSelection().get(0).getTimeBase().get(0).getBelowAboveKMRange() - selectedVehicleCategory.getPriceSelection().get(0).getTimeBase().get(0).getMinimumKM()) * dispatchModel.getUnitCost()
                                + (dispatchModel.getDistance() - selectedVehicleCategory.getPriceSelection().get(0).getTimeBase().get(0).getBelowAboveKMRange()) * selectedVehicleCategory.getPriceSelection().get(0).getTimeBase().get(0).getAboveKMFare());
        }
        this.totalCost.setText("Rs. " + String.valueOf(round(totalCost, 2)));
        dispatchModel.setTotalCost((double)totalCost);
        return totalCost;
    }

    /**
     * round double value with two floating point
     * @param value
     * @param places
     * @return
     */
    public double round(double value, int places) {
        if (places < 0) throw new IllegalArgumentException();

        long factor = (long) Math.pow(10, places);
        value = value * factor;
        long tmp = Math.round(value);
        return (double) tmp / factor;
    }

    /**
     * google map ready method
     * @param googleMap
     */
    @SuppressLint("MissingPermission")
    @Override
    public void onMapReady(GoogleMap googleMap) {
        Permission permission = new Permission(getApplicationContext(), this);
        gmap = googleMap;
        gmap.setMinZoomPreference(1);
        gmap.setMaxZoomPreference(20);
        if (!permission.isLocationPermissionGranted()) {
            permission.checkPermissions();
            return;
        }
        //gmap.setTrafficEnabled(true);
        gmap.setMyLocationEnabled(true);
        gmap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 16.0f));
        gmap.setOnMyLocationButtonClickListener(new GoogleMap.OnMyLocationButtonClickListener() {
            @Override
            public boolean onMyLocationButtonClick() {
                gmap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 16.0f));
                return false;
            }
        });
    }
    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        Bundle mapViewBundle = outState.getBundle(MAP_VIEW_BUNDLE_KEY);
        if (mapViewBundle == null) {
            mapViewBundle = new Bundle();
            outState.putBundle(MAP_VIEW_BUNDLE_KEY, mapViewBundle);
        }

        mapView.onSaveInstanceState(mapViewBundle);
    }

    @Override
    public void onResume() {
        super.onResume();
        mapView.onResume();
    }

    @Override
    public void onStart() {
        super.onStart();
        mapView.onStart();
    }

    @Override
    public void onStop() {
        super.onStop();
        mapView.onStop();
    }

    @Override
    public void onPause() {
        mapView.onPause();
        super.onPause();
    }

    @Override
    public void onDestroy() {
        mapView.onDestroy();
        super.onDestroy();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        mapView.onLowMemory();
    }

    public static float dpToPx(Context context, float valueInDp) {
        DisplayMetrics metrics = context.getResources().getDisplayMetrics();
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, valueInDp, metrics);
    }

}
