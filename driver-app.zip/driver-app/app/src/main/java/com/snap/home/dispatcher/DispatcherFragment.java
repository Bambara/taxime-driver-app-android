package com.snap.home.dispatcher;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.core.content.ContextCompat;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.snap.R;
import com.snap.config.KeyString;
import com.snap.home.driver.DriverFragment;
import com.snap.model.DispatchHistoryModel;
import com.snap.rest.ApiInterface;
import com.snap.rest.JsonApiClient;
import com.snap.session.LoginSession;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DispatcherFragment extends Fragment {
    private Button dispatchButton, switchDriverButton, historyButton;
    private TextView tripCount, earnings;
    ProgressDialog progressDialog;
    public DispatchHistoryModel dispatchHistory = null;

    public static DispatcherFragment newInstance() {
        DispatcherFragment fragment = new DispatcherFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @SuppressLint("ResourceAsColor")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View myFragmentView =  inflater.inflate(R.layout.fragment_dispatcher, container, false);
        /**
         * set status bar colour
         */
        Window window = getActivity().getWindow();   // clear FLAG_TRANSLUCENT_STATUS flag:
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);  // add FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS flag to the window
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);   // finally change the color
        window.setStatusBarColor(ContextCompat.getColor(getContext(), R.color.greenOne));

//        getDispatchHistory();

        tripCount = myFragmentView.findViewById(R.id.trip_count);
        earnings = myFragmentView.findViewById(R.id.earning_amount);
        dispatchButton = myFragmentView.findViewById(R.id.dispatch_button);
        dispatchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (new LoginSession(getContext()).getDispatcherEnale() == false) {
                    AlertDialog alertDialog = new AlertDialog.Builder(getContext()).create();
                    alertDialog.setTitle("Dispatcher Disable");
                    alertDialog.setMessage("please contact snap team");
                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.show();
                } else {
                    Intent intent = new Intent(getContext(), DispatcherFormActivity.class);
                    startActivity(intent);
                }
            }
        });

        switchDriverButton = myFragmentView.findViewById(R.id.driver_button);
        switchDriverButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!new LoginSession(getContext()).getDriverState().equals(KeyString.ONLINE)) {
                    AlertDialog alertDialog = new AlertDialog.Builder(getContext()).create();
                    alertDialog.setTitle("Driver Offline");
                    alertDialog.setMessage("please change driver state as online");
                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.show();
                } else {
                    getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.fragment, DriverFragment.newInstance()).commit();
                }
            }
        });

        historyButton = myFragmentView.findViewById(R.id.history_button);
        historyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (dispatchHistory != null) {
                    Intent intent = new Intent(getContext(), DispatchHistoryActivity.class);
                    intent.putExtra(KeyString.DISPATCH_HISTORY_MODEL, new Gson().toJson(dispatchHistory));
                    startActivity(intent);
                } else {
                    Toast.makeText(getContext(), "Something went wrong", Toast.LENGTH_LONG).show();
                }
            }
        });

        return myFragmentView;
    }

    /**
     * get dispatch history API call
     */
    private void getDispatchHistory() {
        progressDialog = new ProgressDialog(getContext());
        progressDialog.setMessage("Loading...");
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();

        ApiInterface apiInterface = JsonApiClient.getApiClient().create(ApiInterface.class);
        Call<DispatchHistoryModel> call = apiInterface.getDispatchHistory(new LoginSession(getContext()).getUserDetails().getContent().getId());
        call.enqueue(new Callback<DispatchHistoryModel>() {
            @Override
            public void onResponse(Call<DispatchHistoryModel> call, Response<DispatchHistoryModel> response) {
                progressDialog.dismiss();
                if (response.code() == 200) {
                    dispatchHistory = response.body();
                    tripCount.setText(dispatchHistory.getTotalDispatchesDone() + " " + getResources().getString(R.string.trips));
                    earnings.setText(getResources().getString(R.string.rs) + String.valueOf(round(dispatchHistory.getTotalDispatchEarnings(), 2)));
                }
            }

            @Override
            public void onFailure(Call<DispatchHistoryModel> call, Throwable t) {
                progressDialog.dismiss();
            }
        });
    }

    @Override
    public void onResume() {
        getDispatchHistory();
        super.onResume();
    }

    /**
     * round double value with two floating point
     * @param value
     * @param places
     * @return
     */
    public double round(double value, int places) {
        if (places < 0) throw new IllegalArgumentException();

        long factor = (long) Math.pow(10, places);
        value = value * factor;
        long tmp = Math.round(value);
        return (double) tmp / factor;
    }

}
