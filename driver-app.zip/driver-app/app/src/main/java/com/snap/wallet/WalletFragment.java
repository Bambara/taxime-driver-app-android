package com.snap.wallet;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.os.Bundle;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.snap.R;
import com.snap.model.WalletDataModel;
import com.snap.rest.ApiInterface;
import com.snap.rest.JsonApiClient;
import com.snap.session.LoginSession;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class WalletFragment extends Fragment {
    private TextView earnings, walletPoints, error;
    ProgressDialog progressDialog;
    private ConstraintLayout backButton;

    public static WalletFragment newInstance() {
        WalletFragment fragment = new WalletFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @SuppressLint("ResourceAsColor")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View myFragmentView =  inflater.inflate(R.layout.fragment_walet, container, false);

        earnings = myFragmentView.findViewById(R.id.earnings);
        walletPoints = myFragmentView.findViewById(R.id.wallet_points);
        error = myFragmentView.findViewById(R.id.error);
        backButton = myFragmentView.findViewById(R.id.back_button);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().onBackPressed();
            }
        });
        getWalletData();

        return myFragmentView;
    }

    /**
     * get wallet data API call
     */
    private void getWalletData() {
        progressDialog = new ProgressDialog(getContext());
        progressDialog.setMessage("Loading...");
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();

        ApiInterface apiInterface = JsonApiClient.getApiClient().create(ApiInterface.class);
        Call<WalletDataModel> call = apiInterface.getWalletData(new LoginSession(getContext()).getUserDetails().getContent().getId());
        call.enqueue(new Callback<WalletDataModel>() {
            @Override
            public void onResponse(Call<WalletDataModel> call, Response<WalletDataModel> response) {
                progressDialog.dismiss();
                if (response.code() == 200) {
                    earnings.setText(getContext().getResources().getString(R.string.rs) + " " + round(response.body().getContent().getAdminEarnings() + response.body().getContent().getDriverEarnings(), 2));
                    walletPoints.setText(String.valueOf(round(response.body().getContent().getTotalWalletPoints(), 2)));
                } else {
                    error.setText(getResources().getString(R.string.something_went_wrong_please_try_again_later));
                }
            }

            @Override
            public void onFailure(Call<WalletDataModel> call, Throwable t) {
                progressDialog.dismiss();
                error.setText(getResources().getString(R.string.something_went_wrong_please_try_again_later));
            }
        });
    }

    /**
     * round double value with two floating point
     * @param value
     * @param places
     * @return
     */
    public double round(double value, int places) {
        if (places < 0) throw new IllegalArgumentException();

        long factor = (long) Math.pow(10, places);
        value = value * factor;
        long tmp = Math.round(value);
        return (double) tmp / factor;
    }
}
