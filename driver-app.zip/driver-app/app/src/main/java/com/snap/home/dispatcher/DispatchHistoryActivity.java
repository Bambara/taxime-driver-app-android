package com.snap.home.dispatcher;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import com.google.gson.Gson;
import com.snap.R;
import com.snap.adapters.DispatchHistoryAdapter;
import com.snap.config.KeyString;
import com.snap.model.DispatchHistoryModel;

public class DispatchHistoryActivity extends AppCompatActivity {
    private ConstraintLayout backButton;
    public DispatchHistoryModel dispatchHistory = null;
    private RecyclerView dispatchList;
    private DispatchHistoryAdapter adapter;
    private TextView error;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dispatch_history);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);

        Bundle bundle = getIntent().getExtras();
        String json = bundle.getString(KeyString.DISPATCH_HISTORY_MODEL);
        Gson gson = new Gson();
        dispatchHistory = gson.fromJson(json, DispatchHistoryModel.class);

        dispatchList = findViewById(R.id.my_hires_recycler_view);
        error = findViewById(R.id.error);

        if (dispatchHistory.getDispatchHistories().size() > 0) {
            dispatchList.setLayoutManager(new LinearLayoutManager(dispatchList.getContext(), LinearLayoutManager.VERTICAL,false));
            dispatchList.setHasFixedSize(true);
            adapter = new DispatchHistoryAdapter(getApplicationContext(), dispatchHistory.getDispatchHistories());
            dispatchList.setAdapter(adapter);
        } else {
            error.setText(getResources().getString(R.string.no_data_available));
        }

        backButton = findViewById(R.id.back_button);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }

    /**
     * round double value with two floating point
     * @param value
     * @param places
     * @return
     */
    public double round(double value, int places) {
        if (places < 0) throw new IllegalArgumentException();

        long factor = (long) Math.pow(10, places);
        value = value * factor;
        long tmp = Math.round(value);
        return (double) tmp / factor;
    }
}
