package com.snap.register;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.cardview.widget.CardView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.snap.R;
import com.snap.config.KeyString;
import com.snap.config.Permission;

public class RegisterFormThreeFragment extends Fragment {
    private CardView licenceFront, licenceBack, nicFront, nicBack;
    public ImageView licenceFrontImage, licenceBackImage, nicFrontImage, nicBackImsge;
    public TextView errorText;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View myFragmentView =  inflater.inflate(R.layout.fragment_register_form_three, container, false);

        errorText = myFragmentView.findViewById(R.id.error_text);
        licenceFrontImage = myFragmentView.findViewById(R.id.licence_front_image);
        licenceBackImage = myFragmentView.findViewById(R.id.licence_back_image);
        nicFrontImage = myFragmentView.findViewById(R.id.nic_front_image);
        nicBackImsge = myFragmentView.findViewById(R.id.nic_back_image);

        licenceFront = myFragmentView.findViewById(R.id.licence_front);
        licenceFront.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPictureDialog(KeyString.DRIVING_LICENCE_FRONT);
            }
        });
        licenceBack = myFragmentView.findViewById(R.id.licence_back);
        licenceBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPictureDialog(KeyString.DRIVING_LICENCE_BACK);
            }
        });
        nicFront = myFragmentView.findViewById(R.id.nic_front);
        nicFront.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPictureDialog(KeyString.NIC_FRONT);
            }
        });
        nicBack = myFragmentView.findViewById(R.id.nic_back);
        nicBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPictureDialog(KeyString.NIC_BACK);
            }
        });

        return myFragmentView;
    }

    private void showPictureDialog(final String d){
        Permission permission = new Permission(getContext(), getActivity());
        if (!permission.isCameraPermissionGranted() || !permission.isStoragePermissionGranted()) {
            permission.checkPermissions();
            return;
        }
        AlertDialog.Builder pictureDialog = new AlertDialog.Builder(getContext());
        pictureDialog.setTitle("Select Action");
        String[] pictureDialogItems = {"Select photo from gallery", "Capture photo from camera" };
        pictureDialog.setItems(pictureDialogItems,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which) {
                            case 0:
                                ((RegisterActivity)getActivity()).choosePhotoFromGallary(d);
                                break;
                            case 1:
                                ((RegisterActivity)getActivity()).takePhotoFromCamera(d);
                                break;
                        }
                    }
                });
        pictureDialog.show();
    }

}
