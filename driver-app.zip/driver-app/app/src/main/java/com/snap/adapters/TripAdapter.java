package com.snap.adapters;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.CountDownTimer;
import android.os.Vibrator;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.snap.R;
import com.snap.config.KeyString;
import com.snap.gps.GPSTracker;
import com.snap.home.driver.OnTripActivity;
import com.snap.model.tripAcceptModel.DispatchTripAcceptRequestModel;
import com.snap.model.tripAcceptModel.PassengerTripAcceptRequestModel;
import com.snap.model.tripAcceptModel.TripAcceptResponseModel;
import com.snap.model.tripModel.TripModel;
import com.snap.rest.ApiInterface;
import com.snap.rest.JsonApiClient;
import com.snap.session.LoginSession;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class TripAdapter extends RecyclerView.Adapter<TripAdapter.MyViewHolder>{
    Context context;
    List<TripModel> tripModelList;
    ProgressDialog progressDialog;
   // private Handler handler;


    public class MyViewHolder extends RecyclerView.ViewHolder {
        CountDownTimer countDownTimer;
        TextView timer, pickupAddress, dropAddress, date, time, numberOfPassengers, distance, totalAmount, accept;
        ProgressBar progressBar;

        public MyViewHolder(View itemView) {
            super(itemView);

            timer = itemView.findViewById(R.id.timer);
            pickupAddress = itemView.findViewById(R.id.pickup_address);
            dropAddress = itemView.findViewById(R.id.drop_address);
            date = itemView.findViewById(R.id.date);
            time = itemView.findViewById(R.id.time);
            numberOfPassengers = itemView.findViewById(R.id.number_of_passengers);
            distance = itemView.findViewById(R.id.distence);
            totalAmount = itemView.findViewById(R.id.total_amount);
            progressBar = itemView.findViewById(R.id.progress_bar);
            accept = itemView.findViewById(R.id.accept);
        }
    }

    public TripAdapter(Context context, List<TripModel> tripModels){
        this.context = context;
        this.tripModelList = tripModels;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.trip_row_item, parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final MyViewHolder holder, final int position) {

        final Vibrator vibe = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
        holder.pickupAddress.setText(tripModelList.get(position).getPickupLocation().getAddress());
        if (tripModelList.get(position).getType().equals(KeyString.PASSENGER_TRIP)) {
            holder.dropAddress.setText(tripModelList.get(position).getDropLocations().get(0).getAddress());
        } else {
            holder.dropAddress.setText(tripModelList.get(position).getDropLocations().get(0).getAddress());
        }
        holder.date.setText(tripModelList.get(position).getPickupDateTime().substring(0,10));
        holder.time.setText(tripModelList.get(position).getPickupDateTime().substring(11,16));
        holder.numberOfPassengers.setText(tripModelList.get(position).getNoOfPassengers() + " " + context.getResources().getString(R.string.passengers));
        holder.distance.setText(tripModelList.get(position).getDistance() + " " + context.getResources().getString(R.string.km));
        holder.totalAmount.setText(context.getResources().getString(R.string.rs) + round(tripModelList.get(position).getHireCost(), 2));
        holder.accept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                vibe.vibrate(50);
                if (tripModelList.get(position).getType().equals(KeyString.PASSENGER_TRIP)) {
                    PassengerTripAcceptRequestModel model = new PassengerTripAcceptRequestModel();
                    model.setId(tripModelList.get(position).getId());
                    model.setDriverId(new LoginSession(context).getUserDetails().getContent().getId());
                    model.setVehicleId(new LoginSession(context).getVehicle().getId());
                    model.setPassengerId(tripModelList.get(position).getPassengerDetails().getId());
                    model.setType(tripModelList.get(position).getType());
                    model.setVehicleSubCategory(tripModelList.get(position).getVehicleSubCategory());
                    model.setVehicleCategory(tripModelList.get(position).getVehicleCategory());
                    model.setPickupLocation(tripModelList.get(position).getPickupLocation());
                    model.setCustomerTelephoneNo(tripModelList.get(position).getPassengerDetails().getContactNumber());
                    model.setCurrentLocationLatitude(new GPSTracker(context).getLatitude());
                    model.setCurrentLocationLongitude(new GPSTracker(context).getLongitude());

                    acceptLiveTrip(model, tripModelList.get(position));
                } else {
                    DispatchTripAcceptRequestModel model = new DispatchTripAcceptRequestModel();
                    model.setId(tripModelList.get(position).getId());
                    model.setDispatcherId(tripModelList.get(position).getDispatcherId());
                    LoginSession session = new LoginSession(context);
                    model.setDriverId(session.getUserDetails().getContent().getId());
                    model.setVehicleId(session.getVehicle().getId());
                    model.setType(tripModelList.get(position).getType());
                    model.setVehicleSubCategory(tripModelList.get(position).getVehicleSubCategory());
                    model.setVehicleCategory(tripModelList.get(position).getVehicleCategory());
                    model.setCustomerTelephoneNo(tripModelList.get(position).getMobileNumber());
                    DispatchTripAcceptRequestModel.Location location = new DispatchTripAcceptRequestModel.Location();
                    location.setAddress(tripModelList.get(position).getPickupLocation().getAddress());
                    location.setLatitude(tripModelList.get(position).getPickupLocation().getLatitude());
                    location.setLongitude(tripModelList.get(position).getPickupLocation().getLongitude());
                    model.setPickupLocation(location);

                    acceptDispatch(model, tripModelList.get(position));
                }
            }
        });
        if (tripModelList.get(position).getType().equals(KeyString.PASSENGER_TRIP)) {

        } else {

        }

        float progress = ((tripModelList.get(position).getExpireTime() - (int)System.currentTimeMillis()/1000)*100)/tripModelList.get(position).getValidTime();
        Log.i("TAG_PROGRESS", String.valueOf(progress));
        //progressBar.setProgress(Integer.parseInt(pro));

        if (holder.countDownTimer != null) holder.countDownTimer.cancel();
        holder.countDownTimer = new CountDownTimer((tripModelList.get(position).getExpireTime()*1000 - (int)System.currentTimeMillis()), 50) {
            @Override
            public void onTick(long millisUntilFinished) {
                try {
                    holder.progressBar.setProgress((int)(10000 - Math.round(((double)millisUntilFinished/(tripModelList.get(position).getValidTime()*1000))*10000)));
                    holder.timer.setText(String.valueOf((int)millisUntilFinished/1000)+"S");
                } catch (Exception e) {

                }
            }

            @Override
            public void onFinish() {

            }
        }.start();
    }

    @Override
    public int getItemCount() {
        return tripModelList.size();
    }

    /**
     * passenger trip accept api call
     * start OnTripActivity
     * passing tripModel and pricingModel through intent
     * @param model
     * @param tripModel
     */
    private void acceptLiveTrip(PassengerTripAcceptRequestModel model, final TripModel tripModel) {
        progressDialog = new ProgressDialog(context);
        progressDialog.setMessage("Loading...");
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();

        ApiInterface apiInterface = JsonApiClient.getApiClient().create(ApiInterface.class);
        Call<TripAcceptResponseModel> call = apiInterface.acceptLiveTrip(model);
        call.enqueue(new Callback<TripAcceptResponseModel>() {
            @Override
            public void onResponse(Call<TripAcceptResponseModel> call, Response<TripAcceptResponseModel> response) {
                progressDialog.dismiss();
                if (response.code() == 200) {
                    Intent intent = new Intent(context, OnTripActivity.class);
                    intent.putExtra(KeyString.TRIP_MODEL, new Gson().toJson(tripModel));
                    intent.putExtra(KeyString.TRIP_PRICE_MODEL, new Gson().toJson(response.body()));
                    context.startActivity(intent);
                }else if (response.code() == 208) {
                    Toast.makeText(context, "Trip Expired", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(context, "Something went wrong...", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<TripAcceptResponseModel> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(context, "Something went wrong...", Toast.LENGTH_SHORT).show();
            }
        });
    }

    /**
     * dispatch trip accept API call
     * start OnTripActivity
     * passing tripModel and pricingModel through intent
     * @param model
     * @param tripModel
     */
    private void acceptDispatch(DispatchTripAcceptRequestModel model, final TripModel tripModel) {
        progressDialog = new ProgressDialog(context);
        progressDialog.setMessage("Loading...");
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();

        ApiInterface apiInterface = JsonApiClient.getApiClient().create(ApiInterface.class);
        Call<TripAcceptResponseModel> call = apiInterface.acceptDispatch(model);
        call.enqueue(new Callback<TripAcceptResponseModel>() {
            @Override
            public void onResponse(Call<TripAcceptResponseModel> call, Response<TripAcceptResponseModel> response) {
                progressDialog.dismiss();
                if (response.code() == 200) {
                    Intent intent = new Intent(context, OnTripActivity.class);
                    intent.putExtra(KeyString.TRIP_MODEL, new Gson().toJson(tripModel));
                    intent.putExtra(KeyString.TRIP_PRICE_MODEL, new Gson().toJson(response.body()));
                    context.startActivity(intent);
                }else if (response.code() == 208) {
                    Toast.makeText(context, "Trip Expired", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(context, "Something went wrong...", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<TripAcceptResponseModel> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(context, "Something went wrong...", Toast.LENGTH_SHORT).show();
            }
        });
    }

    /**
     * round double value with two floating point
     * @param value
     * @param places
     * @return
     */
    public double round(double value, int places) {
        if (places < 0) throw new IllegalArgumentException();

        long factor = (long) Math.pow(10, places);
        value = value * factor;
        long tmp = Math.round(value);
        return (double) tmp / factor;
    }
}
