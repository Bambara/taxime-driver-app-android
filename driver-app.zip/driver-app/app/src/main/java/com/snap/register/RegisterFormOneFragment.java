package com.snap.register;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;

import com.snap.R;
import com.snap.config.KeyString;
import com.snap.config.Permission;
import com.snap.config.SoftKeyboard;
import com.snap.validation.Formvalidation;

import java.util.Calendar;

import de.hdodenhof.circleimageview.CircleImageView;

public class RegisterFormOneFragment extends Fragment implements View.OnClickListener{
    public CircleImageView profileImage;
    private EditText firstName, lastName, email, mobileNumber;
    private ImageView firstNameError, lastNameError, mobileNumberError, emailError, dobError;
    private int mYear, mMonth, mDay;
    private TextView birthDay;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View myFragmentView =  inflater.inflate(R.layout.fragment_register_form_one, container, false);

        myFragmentView.findViewById(R.id.root_layout_register_form_one_activity).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                SoftKeyboard.hideSoftKeyboard(getActivity());
                return false;
            }
        });

        firstName = myFragmentView.findViewById(R.id.first_name);
        lastName = myFragmentView.findViewById(R.id.last_name);
        birthDay = myFragmentView.findViewById(R.id.birthday);
        birthDay.setOnClickListener(this);
        email = myFragmentView.findViewById(R.id.email);
        mobileNumber = myFragmentView.findViewById(R.id.mobile_number);

        firstNameError = myFragmentView.findViewById(R.id.first_name_error);
        lastNameError = myFragmentView.findViewById(R.id.last_name_error);
        dobError = myFragmentView.findViewById(R.id.dob_error);
        emailError = myFragmentView.findViewById(R.id.email_error);
        mobileNumberError = myFragmentView.findViewById(R.id.mobile_number_error);

        profileImage = myFragmentView.findViewById(R.id.profile_image);
        profileImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPictureDialog(KeyString.PROFILE_IMAGE);
            }
        });

        validate("listener");
        return myFragmentView;
    }

    private boolean validate(String to) {
        boolean state = false;
        firstName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (Formvalidation.isName(s.toString())) {
                    firstNameError.setImageResource(R.drawable.right_icon);
                } else {
                    firstNameError.setImageResource(R.drawable.wrong_icon);
                }
            }
        });
        lastName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (Formvalidation.isName(s.toString())) {
                    lastNameError.setImageResource(R.drawable.right_icon);
                } else {
                    lastNameError.setImageResource(R.drawable.wrong_icon);
                }
            }
        });
        email.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (Formvalidation.isEmail(s.toString())) {
                    emailError.setImageResource(R.drawable.right_icon);
                } else {
                    emailError.setImageResource(R.drawable.wrong_icon);
                }
            }
        });
        mobileNumber.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (Formvalidation.isMobileNumber(s.toString())) {
                    mobileNumberError.setImageResource(R.drawable.right_icon);
                } else {
                    mobileNumberError.setImageResource(R.drawable.wrong_icon);
                }
            }
        });
        birthDay.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (!birthDay.getText().toString().isEmpty()) {
                    dobError.setImageResource(R.drawable.right_icon);
                } else {
                    dobError.setImageResource(R.drawable.wrong_icon);
                }
            }
        });

        if (to.equals("all")
                && Formvalidation.isName(firstName.getText().toString())
                && Formvalidation.isName(lastName.getText().toString())
                && Formvalidation.isMobileNumber(mobileNumber.getText().toString())
                && Formvalidation.isEmail(email.getText().toString())
                && !birthDay.getText().toString().isEmpty()) {
            state = true;
        } else if (to.equals("all")) {
            if (!Formvalidation.isName(firstName.getText().toString())) {
                firstNameError.setImageResource(R.drawable.wrong_icon);
            }
            if (!Formvalidation.isName(lastName.getText().toString())) {
                lastNameError.setImageResource(R.drawable.wrong_icon);
            }
            if (!Formvalidation.isEmail(email.getText().toString())) {
                emailError.setImageResource(R.drawable.wrong_icon);
            }
            if (!Formvalidation.isMobileNumber(mobileNumber.getText().toString())) {
                mobileNumberError.setImageResource(R.drawable.wrong_icon);
            }
            if (birthDay.getText().toString().isEmpty()) {
                dobError.setImageResource(R.drawable.wrong_icon);
            }
        }
        return state;
    }

    private void showPictureDialog(final String d){
        Permission permission = new Permission(getContext(), getActivity());
        if (!permission.isCameraPermissionGranted() || !permission.isStoragePermissionGranted()) {
            permission.checkPermissions();
            return;
        }
        AlertDialog.Builder pictureDialog = new AlertDialog.Builder(getContext());
        pictureDialog.setTitle("Select Action");
        String[] pictureDialogItems = {
                "Select photo from gallery",
                "Capture photo from camera" };
        pictureDialog.setItems(pictureDialogItems,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which) {
                            case 0:
                                ((RegisterActivity)getActivity()).choosePhotoFromGallary(d);
                                break;
                            case 1:
                                ((RegisterActivity)getActivity()).takePhotoFromCamera(d);
                                break;
                        }
                    }
                });
        pictureDialog.show();
    }

    public boolean setData() {
        boolean state = false;
        if (validate("all")) {
            ((RegisterActivity)getActivity()).firstName = firstName.getText().toString();
            ((RegisterActivity)getActivity()).lastName = lastName.getText().toString();
            ((RegisterActivity)getActivity()).birthDay = birthDay.getText().toString();
            ((RegisterActivity)getActivity()).email = email.getText().toString();
            ((RegisterActivity)getActivity()).mobileNumber = mobileNumber.getText().toString();
            //((RegisterActivity)getActivity()).gender = onRadioButtonClicked(v);
            state = true;
        }
        return state;
    }

    public String onRadioButtonClicked(View view) {
        // Is the button now checked?
        boolean checked = ((RadioButton)view).isChecked();
        String state = null;
        // Check which radio button was clicked
        switch(view.getId()) {
            case R.id.male:
                if (checked)
                    state = KeyString.MALE;
                break;
            case R.id.female:
                if (checked)
                    state = KeyString.FEMALE;
                break;
        }
        return state;
    }

    @Override
    public void onClick(View v) {

        if (v == birthDay) {

            // Get Current Date
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);


            DatePickerDialog datePickerDialog = new DatePickerDialog(getContext(), new DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                    birthDay.setText((monthOfYear + 1) + "-" + dayOfMonth + "-" + year);
                    //date = String.valueOf(dayOfMonth) + "/" + String.valueOf(monthOfYear + 1) + "/" + String.valueOf(year);
                }
            }, mYear, mMonth, mDay);
            datePickerDialog.show();
        }
//        if (v == btnTimePicker) {
//
//            // Get Current Time
//            final Calendar c = Calendar.getInstance();
//            mHour = c.get(Calendar.HOUR_OF_DAY);
//            mMinute = c.get(Calendar.MINUTE);
//
//            // Launch Time Picker Dialog
//            TimePickerDialog timePickerDialog = new TimePickerDialog(this,
//                    new TimePickerDialog.OnTimeSetListener() {
//
//                        @Override
//                        public void onTimeSet(TimePicker view, int hourOfDay,
//                                              int minute) {
//
//                            txtTime.setText(hourOfDay + ":" + minute);
//                        }
//                    }, mHour, mMinute, false);
//            timePickerDialog.show();
//        }
    }

}