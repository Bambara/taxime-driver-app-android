package com.snap.other;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.Toast;

import com.github.nkzawa.socketio.client.Socket;
import com.snap.R;
import com.snap.adapters.VehicleSelectAdapter;
import com.snap.model.driverCheckInformationModel.DriverCheckResponseModel;
import com.snap.model.driverConnectModel.DriverConnectedModel;
import com.snap.model.driverCheckInformationModel.DriverCheckRequestModel;
import com.snap.model.vehicleModel.Content;
import com.snap.model.vehicleModel.VehicleModel;
import com.snap.profile.AddVehicleActivity;
import com.snap.rest.ApiInterface;
import com.snap.rest.JsonApiClient;
import com.snap.session.LoginSession;
import com.snap.socket.MySocket;

import java.util.List;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.content.Context.LAYOUT_INFLATER_SERVICE;

public class VehicleSelecterPopup implements VehicleSelectAdapter.SingleClickListener {
    ProgressDialog progressDialog;
    Context context;
    Activity activity;
    VehicleSelectAdapter vehicleSelectAdapter;
    private Content vehicle;
    private Socket mSocket;

    public VehicleSelecterPopup(Context context, Activity activity) {
        this.context = context;
        this.activity = activity;
        this.vehicle = new LoginSession(context).getVehicle();
        getVehicle();
    }

    /**
     * getVehicle api call
     */
    private void getVehicle() {
        progressDialog = new ProgressDialog(activity);
        progressDialog.setMessage("Loading...");
        progressDialog.show();
        DriverConnectedModel model = new DriverConnectedModel();
        model.setDriverId(new LoginSession(context).getUserDetails().getContent().getId());
        Log.i("TAG_DRIVER_ID", model.getDriverId());

        ApiInterface apiInterface = JsonApiClient.getApiClient().create(ApiInterface.class);
        Call<VehicleModel> call = apiInterface.getVehicle(model);
        call.enqueue(new Callback<VehicleModel>() {
            @Override
            public void onResponse(Call<VehicleModel> call, Response<VehicleModel> response) {
                progressDialog.dismiss();
                if (response.code() == 200) {
                    vehiclePopup(response.body());
                } else if (response.code() == 204) {
                    AlertDialog alertDialog = new AlertDialog.Builder(activity).create();
                    alertDialog.setTitle("No Vehicle");
                    alertDialog.setMessage("You have no available vehicle");
                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "Add Vehicle",
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    Intent intent = new Intent(context, AddVehicleActivity.class);
                                    context.startActivity(intent);
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.show();
                } else {
                    AlertDialog alertDialog = new AlertDialog.Builder(activity).create();
                    alertDialog.setTitle("Something Went Wrong...");
                    alertDialog.setMessage("Place try again");
                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.show();
                }
            }

            @Override
            public void onFailure(Call<VehicleModel> call, Throwable t) {
                progressDialog.dismiss();
                AlertDialog alertDialog = new AlertDialog.Builder(activity).create();
                alertDialog.setTitle("Something Went Wrong...");
                alertDialog.setMessage("Place check your internet connection and try again");
                alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                alertDialog.show();
            }
        });
        progressDialog.dismiss();
    }

    /**
     * popup method
     * @param vehicleModel
     */
    private void vehiclePopup(VehicleModel vehicleModel) {

        // Get the widgets reference from XML layout
        LinearLayout layout = activity.findViewById(R.id.root_layout_home_activity);

        // Initialize a new instance of LayoutInflater service
        LayoutInflater inflater = (LayoutInflater) activity.getSystemService(LAYOUT_INFLATER_SERVICE);

        // Inflate the custom layout/view
        View customView = inflater.inflate(R.layout.vehicle_selector_popup,null);

        /*
            public PopupWindow (View contentView, int width, int height)
                Create a new non focusable popup window which can display the contentView.
                The dimension of the window must be passed to this constructor.

                The popup does not provide any background. This should be handled by
                the content view.

            Parameters
                contentView : the popup's content
                width : the popup's width
                height : the popup's height
        */
        // Initialize a new instance of popup window
        final PopupWindow mPopupWindow = new PopupWindow(customView, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        mPopupWindow.setOutsideTouchable(false);

        // Set an elevation value for popup window
        // Call requires API level 21
        if(Build.VERSION.SDK_INT >= 21){
            mPopupWindow.setElevation(5.0f);
        }

        int selected = -1;
        LoginSession session = new LoginSession(context);
        try {
            if (session.getVehicle().getId() != null) {
                for (int i = 0; i < vehicleModel.getContent().size(); i++) {
                    if (session.getVehicle().getId().equals(vehicleModel.getContent().get(i).getId())) selected = i;
                }
            }
        } catch (Exception e) {

        }

        ImageView cancelImage = customView.findViewById(R.id.cancel_image);
        RecyclerView recyclerView = customView.findViewById(R.id.vehicle_recyclerview);
        Button addVehicleButton = customView.findViewById(R.id.add_vehicle_button);
        Button okButton = customView.findViewById(R.id.ok_button);
        Button cancelButton = customView.findViewById(R.id.cancel_button);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(recyclerView.getContext(), LinearLayoutManager.VERTICAL,false);
        recyclerView.setLayoutManager(linearLayoutManager);
        recyclerView.setHasFixedSize(true);
        vehicleSelectAdapter = new VehicleSelectAdapter(context, vehicleModel.getContent(), selected);
        recyclerView.setAdapter(vehicleSelectAdapter);
        vehicleSelectAdapter.setOnItemClickListener(this);

        cancelImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mPopupWindow.dismiss();
            }
        });

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mPopupWindow.dismiss();
            }
        });

        okButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                MySocket mySocket = (MySocket)activity.getApplication();
//                new LoginSession(activity).createVehicleSession(vehicle);
//                SocketReconnect.driverConnect(context, mySocket.getmSocket());
//                mPopupWindow.dismiss();
                if (vehicle == null) {
                    Toast.makeText(context, "Please select a vehicle", Toast.LENGTH_SHORT).show();
                } else {
                    selectVehicleApiCall(mPopupWindow, vehicle);
                }
            }
        });

        addVehicleButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent intent = new Intent(context, AddVehicleActivity.class);
                    context.startActivity(intent);
                } catch (Exception e) {

                }
                mPopupWindow.dismiss();
            }
        });

        /*
            public void showAtLocation (View parent, int gravity, int x, int y)
                Display the content view in a popup window at the specified location. If the
                popup window cannot fit on screen, it will be clipped.
                Learn WindowManager.LayoutParams for more information on how gravity and the x
                and y parameters are related. Specifying a gravity of NO_GRAVITY is similar
                to specifying Gravity.LEFT | Gravity.TOP.

            Parameters
                parent : a parent view to get the getWindowToken() token from
                gravity : the gravity which controls the placement of the popup window
                x : the popup's x location offset
                y : the popup's y location offset
        */
        // Finally, show the popup window at the center location of root relative layout
        mPopupWindow.showAtLocation(layout, Gravity.CENTER,0,0);
    }

    @Override
    public void onItemClickListener(int position, List<Content> vehicleList) {
        vehicleSelectAdapter.selectedItem();
        vehicle = vehicleList.get(position);
    }

    /**
     * API call for the select vehicle
     * @param mPopupWindow
     * @param vehicle
     */
    private void selectVehicleApiCall(final PopupWindow mPopupWindow, final Content vehicle) {
        DriverCheckRequestModel model = new DriverCheckRequestModel();
        LoginSession session = new LoginSession(context);
        model.setDriverId(session.getUserDetails().getContent().getId());
        model.setVehicleId(vehicle.getId());

        progressDialog = new ProgressDialog(activity);
        progressDialog.setMessage("Loading...");
        progressDialog.show();
        ApiInterface apiInterface = JsonApiClient.getApiClient().create(ApiInterface.class);
        Call<ResponseBody> call = apiInterface.selectVehicle(model);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                progressDialog.dismiss();
                Log.i("TAG CHECK DRIVER CODE", String.valueOf(response.code()));
                if (response.code() == 200) {
                    MySocket socket = (MySocket)activity.getApplication();
                    mSocket = socket.getmSocket();
                    new LoginSession(activity).createVehicleSession(vehicle);
                    //SocketReconnect.driverConnect(context, mySocket.getmSocket());
                    boolean state = true;
                    while (state) {
                        if (mSocket.connected()) {
                            SocketReconnect.driverConnect(context, mSocket);
                            state = false;
                            Log.i("TAG_DRIVER_CONNECT", "true");
                        } else {
                            Log.i("TAG_DRIVER_CONNECT", "false");
                        }
                    }
                    checkDriver(context);
                    mPopupWindow.dismiss();
                } else {
                    AlertDialog alertDialog = new AlertDialog.Builder(activity).create();
                    alertDialog.setTitle("Something Went Wrong...");
                    alertDialog.setMessage("Place try again");
                    alertDialog.setCanceledOnTouchOutside(false);
                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.show();
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                progressDialog.dismiss();
                Log.i("TAG CHECK DRIVER FAIL", t.getMessage());
                AlertDialog alertDialog = new AlertDialog.Builder(activity).create();
                alertDialog.setTitle("Something Went Wrong...");
                alertDialog.setMessage("Place try again");
                alertDialog.setCanceledOnTouchOutside(false);
                alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                alertDialog.show();
            }
        });
    }

    /**
     * method for check driver detail when app starting time
     * @param context
     */
    public static void checkDriver(final Context context) {
        DriverCheckRequestModel model = new DriverCheckRequestModel();
        LoginSession session = new LoginSession(context);
        model.setDriverId(session.getUserDetails().getContent().getId());
        model.setVehicleId(session.getVehicle().getId());

//        progressDialog = new ProgressDialog(context);
//        progressDialog.setMessage("Loading...");
//        progressDialog.show();
        ApiInterface apiInterface = JsonApiClient.getApiClient().create(ApiInterface.class);
        Call<DriverCheckResponseModel> call = apiInterface.driverCheck(model);
        call.enqueue(new Callback<DriverCheckResponseModel>() {
            @Override
            public void onResponse(Call<DriverCheckResponseModel> call, Response<DriverCheckResponseModel> response) {
                //progressDialog.dismiss();
                Log.i("TAG CHECK DRIVER CODE", String.valueOf(response.code()));
                LoginSession session1 = new LoginSession(context);
                if (response.code() == 200) {
                    session1.setDriverEnable(response.body().getDriverDispatch().get(0).isEnable());
                    session1.setDispatcherEnable(response.body().getDriverDispatch().get(0).isDispatchEnable());
                    session1.setVehicleEnable(response.body().getVehicle().isEnable());
                    session1.createSubCategoryImageSession(response.body().getSubCategoryImage());
                    if (response.body().getDriverDispatch().get(0).isDispatchEnable()) {
                        session1.createDispatcherSession(response.body().getDriverDispatch().get(0).getDispatcher().get(0));
                    } else {
                        session1.createDispatcherSession(null);
                    }
                } else if (response.code() == 203) {
                    session1.setDriverEnable(response.body().getDriverDispatch().get(0).isEnable());
                    session1.setDispatcherEnable(response.body().getDriverDispatch().get(0).isDispatchEnable());
                    session1.setVehicleEnable(false);
                }
            }

            @Override
            public void onFailure(Call<DriverCheckResponseModel> call, Throwable t) {
                //progressDialog.dismiss();
                Log.i("TAG CHECK DRIVER FAIL", t.getMessage());

            }
        });
    }
}
