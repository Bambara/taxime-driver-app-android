package com.snap.register;

import android.app.ProgressDialog;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

import com.snap.R;
import com.snap.config.KeyString;
import com.snap.login.OTPVerificationActivity;
import com.snap.rest.FileApiClient;
import com.snap.rest.ApiInterface;
import com.snap.session.LoginSession;

import android.content.Intent;
import android.graphics.Bitmap;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Calendar;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;



public class RegisterActivity extends AppCompatActivity {
    Fragment fragment;
    private Button nextButton;
    private static final String IMAGE_DIRECTORY = "/demonuts";
    private int GALLERY = 1, CAMERA = 2;
    private String direction = null;
    private int state = 0;
    public String firstName, lastName, birthDay, email, mobileNumber, gender = "male",
                    addressLineOne, addressLineTwo, city, postalCode, country, nicNumber, lifeInsuranceNo,  lifeInsuranceExpiryDate;
    private String profileImagePath = null, licenceFrontImagePath = null, licenceBackImagePath = null, nicFrontImagePath = null, nicBackImagePath = null;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.register_fragment,new RegisterFormOneFragment());
        fragmentTransaction.commit();

        nextButton = findViewById(R.id.next_button);
        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                Log.i("TAG STATE", String.valueOf(state));
                switch (state) {
                    case 0:
                        RegisterFormOneFragment fragment = (RegisterFormOneFragment)getSupportFragmentManager().findFragmentById(R.id.register_fragment);
                        if (fragment.setData() && !(profileImagePath == null)) {
                            fragmentTransaction.replace(R.id.register_fragment,new RegisterFormTwoFragment());
                            state = 1;
                        } else if (profileImagePath == null) {
                            Toast.makeText(getApplicationContext(),"Select Your Profile Image", Toast.LENGTH_SHORT).show();
                        }
                        break;
                    case 1:
                        RegisterFormTwoFragment fragment1 = (RegisterFormTwoFragment)getSupportFragmentManager().findFragmentById(R.id.register_fragment);
                        if (fragment1.setData()) {
                            fragmentTransaction.replace(R.id.register_fragment,new RegisterFormThreeFragment());
                            state = 2;
                        }
                        break;
                    case 2:
                        RegisterFormThreeFragment fragment2 = (RegisterFormThreeFragment)getSupportFragmentManager().findFragmentById(R.id.register_fragment);
                        if (licenceFrontImagePath == null || licenceBackImagePath == null || nicFrontImagePath == null || nicBackImagePath == null) {
                            fragment2.errorText.setText(R.string.select_all_images);
                        } else {
                            fragment2.errorText.setText("");
                            fetchData();
                        }
                }
                fragmentTransaction.commit();
            }
        });
    }


    /**
     * driver registration api call
     */
    private void fetchData() {
        progressDialog = new ProgressDialog(RegisterActivity.this);
        progressDialog.setMessage("Loading...");
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();
        ApiInterface apiInterface = FileApiClient.getApiClient(new LoginSession(getApplicationContext()).getUserDetails().getToken()).create(ApiInterface.class);
        Call<ResponseBody> call = apiInterface.driverRegister(
                createPartFromString(firstName),
                createPartFromString(lastName),
                createPartFromString(email),
                createPartFromString(nicNumber),
                createPartFromString(birthDay),
                createPartFromString(mobileNumber),
                createPartFromString(gender),
                createPartFromString(addressLineOne),
                createPartFromString(addressLineTwo),
                createPartFromString(city),
                createPartFromString(postalCode),
                createPartFromString(country),
                prepareFilePart("nicFrontPic", nicFrontImagePath),
                prepareFilePart("nicBackPic", nicBackImagePath),
                prepareFilePart("drivingLicenceFrontPic", licenceFrontImagePath),
                prepareFilePart("drivingLicenceBackPic", licenceBackImagePath),
                createPartFromString(lifeInsuranceNo),
                createPartFromString(lifeInsuranceExpiryDate),
                prepareFilePart("driverPic", profileImagePath),
                createPartFromString("0")
        );
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                progressDialog.dismiss();
                if (response.code() == 200) {
                    Intent intent = new Intent(getApplicationContext(), OTPVerificationActivity.class);
                    intent.putExtra(KeyString.MOBILE_NUMBER, mobileNumber);
                    intent.putExtra(KeyString.PROFILE_IMAGE, profileImagePath);
                    intent.putExtra(KeyString.FIRST_NAME, firstName);
                    startActivity(intent);
                    finish();
                } else if (response.code() == 208){
                    RegisterFormThreeFragment fragment2 = (RegisterFormThreeFragment)getSupportFragmentManager().findFragmentById(R.id.register_fragment);
                    fragment2.errorText.setText(R.string.alredy_registered);
                    //Toast.makeText(getApplicationContext(),"Registration Fail", Toast.LENGTH_SHORT).show();
                } else if (response.code() == 413){
                    RegisterFormThreeFragment fragment2 = (RegisterFormThreeFragment)getSupportFragmentManager().findFragmentById(R.id.register_fragment);
                    fragment2.errorText.setText(R.string.image_size_too_large);
                } else {
                    RegisterFormThreeFragment fragment2 = (RegisterFormThreeFragment)getSupportFragmentManager().findFragmentById(R.id.register_fragment);
                    fragment2.errorText.setText(R.string.something_went_wrong);
                }
                Log.i("TAG RESPONSE CODE", String.valueOf(response.code()));
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                progressDialog.dismiss();
                Log.i("TAG ON FAILURE", t.getMessage());
                //Toast.makeText(getApplicationContext(),"Request fail", Toast.LENGTH_SHORT).show();
                RegisterFormThreeFragment fragment2 = (RegisterFormThreeFragment)getSupportFragmentManager().findFragmentById(R.id.register_fragment);
                fragment2.errorText.setText(R.string.try_again);
            }
        });
    }

    @NonNull
    private RequestBody createPartFromString(String descriptionString) {
        return RequestBody.create(okhttp3.MultipartBody.FORM, descriptionString);
    }

    @NonNull
    private MultipartBody.Part prepareFilePart(String partName, String filePath) {
        // https://github.com/iPaulPro/aFileChooser/blob/master/aFileChooser/src/com/ipaulpro/afilechooser/utils/FileUtils.java
        // use the FileUtils to get the actual file by uri
        File file = new File(filePath);

        // create RequestBody instance from file
        RequestBody requestFile = RequestBody.create(MediaType.parse("image/jpg"), file);

        // MultipartBody.Part is used to send also the actual file name
        return MultipartBody.Part.createFormData(partName, file.getName(), requestFile);
    }

    public void choosePhotoFromGallary(String d) {
        direction = d;
        Intent galleryIntent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(galleryIntent, GALLERY);
    }

    public void takePhotoFromCamera(String d) {
        direction = d;
        Intent intent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
        File file = new File(Environment.getExternalStorageDirectory(), "MyPhoto.jpg");
        Uri uri = FileProvider.getUriForFile(this, this.getApplicationContext().getPackageName() + ".provider", file);
        intent.putExtra(android.provider.MediaStore.EXTRA_OUTPUT, uri);
        startActivityForResult(intent, CAMERA);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == this.RESULT_CANCELED) {
            return;
        }
        if (requestCode == GALLERY) {
            if (data != null) {
                Uri contentURI = data.getData();
                try {
                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), contentURI);
                    //String path = saveImage(bitmap);
                    //Toast.makeText(getApplicationContext(), "Image Saved!", Toast.LENGTH_SHORT).show();
                    switch (direction) {
                        case KeyString.PROFILE_IMAGE:
                            RegisterFormOneFragment fragment = (RegisterFormOneFragment)getSupportFragmentManager().findFragmentById(R.id.register_fragment);
                            fragment.profileImage.setImageBitmap(bitmap);
                            profileImagePath = saveImage(bitmap);
                            break;
                        case KeyString.DRIVING_LICENCE_FRONT:
                            RegisterFormThreeFragment fragment1 = (RegisterFormThreeFragment)getSupportFragmentManager().findFragmentById(R.id.register_fragment);
                            fragment1.licenceFrontImage.setImageBitmap(bitmap);
                            licenceFrontImagePath = saveImage(bitmap);
                            break;
                        case KeyString.DRIVING_LICENCE_BACK:
                            RegisterFormThreeFragment fragment2 = (RegisterFormThreeFragment)getSupportFragmentManager().findFragmentById(R.id.register_fragment);
                            fragment2.licenceBackImage.setImageBitmap(bitmap);
                            licenceBackImagePath = saveImage(bitmap);
                            break;
                        case KeyString.NIC_FRONT:
                            RegisterFormThreeFragment fragment3 = (RegisterFormThreeFragment)getSupportFragmentManager().findFragmentById(R.id.register_fragment);
                            fragment3.nicFrontImage.setImageBitmap(bitmap);
                            nicFrontImagePath = saveImage(bitmap);
                            break;
                        case KeyString.NIC_BACK:
                            RegisterFormThreeFragment fragment4 = (RegisterFormThreeFragment)getSupportFragmentManager().findFragmentById(R.id.register_fragment);
                            fragment4.nicBackImsge.setImageBitmap(bitmap);
                            nicBackImagePath = saveImage(bitmap);
                            break;
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                    //Toast.makeText(getApplicationContext(), "Failed!", Toast.LENGTH_SHORT).show();
                }
            }

        } else if (requestCode == CAMERA) {

           //if (data != null) {
               //Uri contentURI = data.getData();
               try {
                   //Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), contentURI);
                   //String path = saveImage(bitmap);
                   //File object of camera image
                   File file = new File(Environment.getExternalStorageDirectory(), "MyPhoto.jpg");

                   //Uri of camera image
                   Uri uri = FileProvider.getUriForFile(this, this.getApplicationContext().getPackageName() + ".provider", file);
                   Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), uri);

                   //Bitmap bitmap = data.getExtras().getParcelable("data");
                   switch (direction) {
                       case KeyString.PROFILE_IMAGE:
                           RegisterFormOneFragment fragment = (RegisterFormOneFragment)getSupportFragmentManager().findFragmentById(R.id.register_fragment);
                           fragment.profileImage.setImageBitmap(bitmap);
                           profileImagePath = saveImage(bitmap);
                           break;
                       case KeyString.DRIVING_LICENCE_FRONT:
                           RegisterFormThreeFragment fragment1 = (RegisterFormThreeFragment)getSupportFragmentManager().findFragmentById(R.id.register_fragment);
                           fragment1.licenceFrontImage.setImageBitmap(bitmap);
                           licenceFrontImagePath = saveImage(bitmap);
                           break;
                       case KeyString.DRIVING_LICENCE_BACK:
                           RegisterFormThreeFragment fragment2 = (RegisterFormThreeFragment)getSupportFragmentManager().findFragmentById(R.id.register_fragment);
                           fragment2.licenceBackImage.setImageBitmap(bitmap);
                           licenceBackImagePath = saveImage(bitmap);
                           break;
                       case KeyString.NIC_FRONT:
                           RegisterFormThreeFragment fragment3 = (RegisterFormThreeFragment)getSupportFragmentManager().findFragmentById(R.id.register_fragment);
                           fragment3.nicFrontImage.setImageBitmap(bitmap);
                           nicFrontImagePath = saveImage(bitmap);
                           break;
                       case KeyString.NIC_BACK:
                           RegisterFormThreeFragment fragment4 = (RegisterFormThreeFragment)getSupportFragmentManager().findFragmentById(R.id.register_fragment);
                           fragment4.nicBackImsge.setImageBitmap(bitmap);
                           nicBackImagePath = saveImage(bitmap);
                           break;
                   }
               } catch (Exception e) {
                   e.printStackTrace();
               }
           //}
            //Toast.makeText(getApplicationContext(), "Image Saved!", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * reduce selected image size
     * save resized image
     * return resized image file path
     * @param myBitmap
     * @return
     */
    public String saveImage(Bitmap myBitmap) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        ByteArrayOutputStream size = new ByteArrayOutputStream();

        int quality = 100;
        myBitmap.compress(Bitmap.CompressFormat.JPEG, quality, size);

        int imageSizeKB = size.toByteArray().length/1024;
        if (imageSizeKB > 2000) {
            quality = imageSizeKB < 3000 ? 75 : imageSizeKB < 4000 ? 55 : imageSizeKB < 5000 ? 45 :
                                                imageSizeKB < 6000 ? 38 : imageSizeKB < 7000 ? 32 :
                                                imageSizeKB < 8000 ? 28 : imageSizeKB < 9000 ? 25 :
                                                imageSizeKB < 10000 ? 22 : 15;
            myBitmap.compress(Bitmap.CompressFormat.JPEG, quality, bytes);
        } else {
            myBitmap.compress(Bitmap.CompressFormat.JPEG, quality, bytes);
        }

        File wallpaperDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
        // have the object build the directory structure, if needed.
        if (!wallpaperDirectory.exists()) {
            wallpaperDirectory.mkdirs();
        }

        try {
            File f = new File(wallpaperDirectory, Calendar.getInstance().getTimeInMillis() + ".jpg");
            f.createNewFile();
            FileOutputStream fo = new FileOutputStream(f);
            fo.write(bytes.toByteArray());
            MediaScannerConnection.scanFile(this, new String[]{f.getPath()}, new String[]{"image/jpeg"}, null);
            fo.close();
            Log.d("TAG", "File Saved::---&gt;" + f.getAbsolutePath());

            return f.getAbsolutePath();
        } catch (IOException e1) {
            e1.printStackTrace();
        }
        return "";
    }

}
