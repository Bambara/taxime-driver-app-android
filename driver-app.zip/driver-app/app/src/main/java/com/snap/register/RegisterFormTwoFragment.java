package com.snap.register;

import android.app.DatePickerDialog;
import android.os.Bundle;
import androidx.fragment.app.Fragment;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.snap.R;
import com.snap.config.SoftKeyboard;
import com.snap.validation.Formvalidation;

import java.util.Calendar;

public class RegisterFormTwoFragment extends Fragment implements View.OnClickListener {
    private EditText addressLineOne, addressLineTwo, city, country, postalCode, nicNumber, lifeInsuranceNo;
    private ImageView addressLineOneError, addressLineTwoError, cityError, nicError;
    private int mYear, mMonth, mDay;
    private TextView lifeInsuranceExpiryDate;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View myFragmentView =  inflater.inflate(R.layout.fragment_register_form_two, container, false);

        myFragmentView.findViewById(R.id.root_layout_register_form_two_fragment).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                SoftKeyboard.hideSoftKeyboard(getActivity());
                return false;
            }
        });

        addressLineOne = myFragmentView.findViewById(R.id.address_line_one);
        addressLineTwo = myFragmentView.findViewById(R.id.address_line_two);
        city = myFragmentView.findViewById(R.id.city);
        postalCode = myFragmentView.findViewById(R.id.postal_code);
        country = myFragmentView.findViewById(R.id.country);
        nicNumber = myFragmentView.findViewById(R.id.nic_number);
        lifeInsuranceNo = myFragmentView.findViewById(R.id.life_insurance_no);
        lifeInsuranceExpiryDate = myFragmentView.findViewById(R.id.life_insurance_expiry_date);
        addressLineOneError = myFragmentView.findViewById(R.id.address_line_one_error);
        addressLineTwoError = myFragmentView.findViewById(R.id.address_line_two_error);
        cityError = myFragmentView.findViewById(R.id.city_error);
        nicError = myFragmentView.findViewById(R.id.nic_error);
        lifeInsuranceExpiryDate = myFragmentView.findViewById(R.id.life_insurance_expiry_date);
        lifeInsuranceExpiryDate.setOnClickListener(this);

        validate("listener");
        return myFragmentView;
    }

    private boolean validate(String to) {
        boolean state = false;
        addressLineOne.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (addressLineOne.getText().toString().isEmpty()) {
                    addressLineOneError.setImageResource(R.drawable.wrong_icon);
                } else {
                    addressLineOneError.setImageResource(R.drawable.right_icon);
                }
            }
        });
        addressLineTwo.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (addressLineTwo.getText().toString().isEmpty()) {
                    addressLineTwoError.setImageResource(R.drawable.wrong_icon);
                } else {
                    addressLineTwoError.setImageResource(R.drawable.right_icon);
                }
            }
        });
        city.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (city.getText().toString().isEmpty()) {
                    cityError.setImageResource(R.drawable.wrong_icon);
                } else {
                    cityError.setImageResource(R.drawable.right_icon);
                }
            }
        });
        nicNumber.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (Formvalidation.isNIC(nicNumber.getText().toString())) {
                    nicError.setImageResource(R.drawable.right_icon);
                } else {
                    nicError.setImageResource(R.drawable.wrong_icon);
                }
            }
        });

        if (to.equals("all")
                && !addressLineOne.getText().toString().isEmpty()
                && !addressLineTwo.getText().toString().isEmpty()
                && !city.getText().toString().isEmpty()
                && Formvalidation.isNIC(nicNumber.getText().toString())) {
            state = true;
        } else if (to.equals("all")) {
            if (addressLineOne.getText().toString().isEmpty()) {
                addressLineOneError.setImageResource(R.drawable.wrong_icon);
            }
            if (addressLineTwo.getText().toString().isEmpty()) {
                addressLineTwoError.setImageResource(R.drawable.wrong_icon);
            }
            if (city.getText().toString().isEmpty()) {
                cityError.setImageResource(R.drawable.wrong_icon);
            }
            if (!Formvalidation.isNIC(nicNumber.getText().toString())) {
                nicError.setImageResource(R.drawable.wrong_icon);
            }
        }

        return state;
    }

    public boolean setData() {
        boolean state = false;
        if (validate("all")) {
            ((RegisterActivity)getActivity()).addressLineOne = addressLineOne.getText().toString();
            ((RegisterActivity)getActivity()).addressLineTwo = addressLineTwo.getText().toString();
            ((RegisterActivity)getActivity()).city = city.getText().toString();
            ((RegisterActivity)getActivity()).postalCode = postalCode.getText().toString();
            ((RegisterActivity)getActivity()).country = country.getText().toString();
            ((RegisterActivity)getActivity()).nicNumber = nicNumber.getText().toString();
            ((RegisterActivity)getActivity()).lifeInsuranceNo = lifeInsuranceNo.getText().toString();
            ((RegisterActivity)getActivity()).lifeInsuranceExpiryDate = lifeInsuranceExpiryDate.getText().toString();
            state = true;
        }
        return state;
    }

    @Override
    public void onClick(View v) {

        if (v == lifeInsuranceExpiryDate) {

            // Get Current Date
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);


            DatePickerDialog datePickerDialog = new DatePickerDialog(getContext(), new DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                    lifeInsuranceExpiryDate.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year);
                    //date = String.valueOf(dayOfMonth) + "/" + String.valueOf(monthOfYear + 1) + "/" + String.valueOf(year);
                }
            }, mYear, mMonth, mDay);
            datePickerDialog.show();
        }
    }

}
