package com.snap.profile;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import androidx.annotation.NonNull;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.cardview.widget.CardView;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.snap.R;
import com.snap.config.KeyString;
import com.snap.config.Permission;
import com.snap.config.SoftKeyboard;
import com.snap.other.DriverNotApprovedActivity;
import com.snap.rest.ApiInterface;
import com.snap.rest.FileApiClient;
import com.snap.session.LoginSession;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Calendar;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddVehicleActivity extends AppCompatActivity {

    private String vehicleBrand, vehicleModel, vehicleColor, weightLimit, passengerCapacity, vehicleRegisterNumber,
            vehicleBookImagePath, vehicleInsurenceImagePath, vehicleFrontImagePath, vehicleSideImagePath;
    private EditText brand, model, color, weight, passenger, registerNumber;
    private CardView vehicleBookCard, vehicleInsuranceCard, vehicleFrontCard, vehicleSideViewCard;
    private Button submit;
    private ImageView vehicleBookImage, vehicleInsuranceImage, vehicleFrontImage, vehicleSideViewImage, vehucleBrandValidationImage, vehicleRegisterNumberValidationImage;
    ProgressDialog progressDialog;
    private static final String IMAGE_DIRECTORY = "/demonuts";
    private int GALLERY = 1, CAMERA = 2;
    private String direction = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_vehicale);

        findViewById(R.id.rot_layout_add_vehicle_activity).setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                SoftKeyboard.hideSoftKeyboard(AddVehicleActivity.this);
                return false;
            }
        });

        brand = findViewById(R.id.vehicle_brand);
        model = findViewById(R.id.vehicle_model);
        color = findViewById(R.id.vehicle_color);
        weight = findViewById(R.id.weight_limit);
        passenger = findViewById(R.id.passenger_capacity);
        registerNumber = findViewById(R.id.vehicle_register_number);
        vehicleBookCard = findViewById(R.id.vehicle_book);
        vehicleInsuranceCard = findViewById(R.id.vehicle_insurance);
        vehicleFrontCard = findViewById(R.id.vehicle_front);
        vehicleSideViewCard = findViewById(R.id.vehicle_side_view);
        vehicleBookImage = findViewById(R.id.vehicle_book_image);
        vehicleInsuranceImage = findViewById(R.id.vehicle_insurance_image);
        vehicleFrontImage = findViewById(R.id.vehicle_front_image);
        vehicleSideViewImage = findViewById(R.id.vehicle_side_view_image);
        vehucleBrandValidationImage = findViewById(R.id.vehicle_brand_validation_image);
        vehicleRegisterNumberValidationImage = findViewById(R.id.vehicle_register_number_validation_image);
        submit = findViewById(R.id.submit_button);

        vehicleBookCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPictureDialog(KeyString.VEHICLE_BOOK);
            }
        });
        vehicleInsuranceCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPictureDialog(KeyString.VEHICLE_INSURANCE);
            }
        });
        vehicleFrontCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPictureDialog(KeyString.VEHICLE_FRONT);
            }
        });
        vehicleSideViewCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPictureDialog(KeyString.VEHICLE_SIDE_VIEW);
            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if (brand.getText().toString().isEmpty() || model.getText().toString().isEmpty() || color.getText().toString().isEmpty()
                            || weight.getText().toString().isEmpty()  || passenger.getText().toString().isEmpty()  || registerNumber.getText().toString().isEmpty()
                            || vehicleBookImagePath.isEmpty() || vehicleInsurenceImagePath.isEmpty() || vehicleFrontImagePath.isEmpty() || vehicleSideImagePath.isEmpty()) {
                        AlertDialog alertDialog = new AlertDialog.Builder(AddVehicleActivity.this).create();
                        alertDialog.setTitle("Error");
                        alertDialog.setMessage("All data are required");
                        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();
                                    }
                                });
                        alertDialog.show();
                        return;
                    } else {
                        fetchData();
                    }
                } catch (Exception e) {

                }
            }
        });
    }

    /**
     * method for select camera or gallery
     * @param d
     */
    private void showPictureDialog(final String d){
        Permission permission = new Permission(getApplicationContext(), AddVehicleActivity.this);
        if (!permission.isCameraPermissionGranted() || !permission.isStoragePermissionGranted()) {
            permission.checkPermissions();
            return;
        }
        AlertDialog.Builder pictureDialog = new AlertDialog.Builder(AddVehicleActivity.this);
        pictureDialog.setTitle("Select Action");
        String[] pictureDialogItems = {
                "Select photo from gallery",
                "Capture photo from camera" };
        pictureDialog.setItems(pictureDialogItems,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which) {
                            case 0:
                                choosePhotoFromGallary(d);
                                break;
                            case 1:
                                takePhotoFromCamera(d);
                                break;
                        }
                    }
                });
        pictureDialog.show();
    }

    /**
     * add vehicle api call
     */
    private void fetchData() {
        progressDialog = new ProgressDialog(AddVehicleActivity.this);
        progressDialog.setMessage("Loading...");
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();
        LoginSession session = new LoginSession(getApplicationContext());
        ApiInterface apiInterface = FileApiClient.getApiClient(session.getUserDetails().getToken()).create(ApiInterface.class);
        Call<ResponseBody> call = apiInterface.addVehicle(
                createPartFromString(session.getUserDetails().getContent().getFirstName()),
                createPartFromString(session.getUserDetails().getContent().getContactNo()),
                createPartFromString(session.getUserDetails().getContent().getEmail()),
                createPartFromString(registerNumber.getText().toString()),
                createPartFromString(color.getText().toString()),
                createPartFromString(brand.getText().toString()),
                prepareFilePart("vehicleBookPic", vehicleBookImagePath),
                prepareFilePart("vehicleInsurancePic", vehicleInsurenceImagePath),
                prepareFilePart("vehicleFrontPic", vehicleFrontImagePath),
                prepareFilePart("vehicleSideViewPic", vehicleSideImagePath),
                createPartFromString(session.getUserDetails().getContent().getId()),
                createPartFromString(model.getText().toString()),
                createPartFromString(weight.getText().toString()),
                createPartFromString(passenger.getText().toString())
        );
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                progressDialog.dismiss();
                Log.i("TAG_RESPONSE_CODE", String.valueOf(response.code()));
                if (response.code() == 200) {
                    AlertDialog alertDialog = new AlertDialog.Builder(AddVehicleActivity.this).create();
                    alertDialog.setCanceledOnTouchOutside(true);
                    alertDialog.setTitle("Successful");
                    alertDialog.setMessage("your vehicle added successfully");
                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    finish();
                                    dialog.dismiss();
                                    if (new LoginSession(getApplicationContext()).getDriverApprove() == true) {
                                        finish();
                                    } else {
                                        Intent intent = new Intent(getApplicationContext(), DriverNotApprovedActivity.class);
                                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                        startActivity(intent);
                                    }
                                }
                            });
                    alertDialog.show();
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                progressDialog.dismiss();
                Log.i("TAG_RESPONSE_CODE", t.getMessage());
                AlertDialog alertDialog = new AlertDialog.Builder(AddVehicleActivity.this).create();
                alertDialog.setTitle("Something Went Wrong");
                alertDialog.setMessage("Check your internet connection and try again latter");
                alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                alertDialog.show();
            }
        });
    }

    @NonNull
    private RequestBody createPartFromString(String descriptionString) {
        return RequestBody.create(
                okhttp3.MultipartBody.FORM, descriptionString);
    }

    @NonNull
    private MultipartBody.Part prepareFilePart(String partName, String filePath) {
        // https://github.com/iPaulPro/aFileChooser/blob/master/aFileChooser/src/com/ipaulpro/afilechooser/utils/FileUtils.java
        // use the FileUtils to get the actual file by uri
        File file = new File(filePath);

        // create RequestBody instance from file
        RequestBody requestFile = RequestBody.create(MediaType.parse("image/jpg"), file);

        // MultipartBody.Part is used to send also the actual file name
        return MultipartBody.Part.createFormData(partName, file.getName(), requestFile);
    }

    public void choosePhotoFromGallary(String d) {
        direction = d;
        Intent galleryIntent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(galleryIntent, GALLERY);
    }

    public void takePhotoFromCamera(String d) {
        direction = d;
        Intent intent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
        File file = new File(Environment.getExternalStorageDirectory(), "MyPhoto.jpg");
        Uri uri = FileProvider.getUriForFile(this, this.getApplicationContext().getPackageName() + ".provider", file);
        intent.putExtra(android.provider.MediaStore.EXTRA_OUTPUT, uri);
        startActivityForResult(intent, CAMERA);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == this.RESULT_CANCELED) {
            return;
        }
        if (requestCode == GALLERY) {
            if (data != null) {
                Uri contentURI = data.getData();
                try {
                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), contentURI);
                    //String path = saveImage(bitmap);
                    //Toast.makeText(getApplicationContext(), "Image Saved!", Toast.LENGTH_SHORT).show();
                    switch (direction) {
                        case KeyString.VEHICLE_BOOK:
                            vehicleBookImage.setImageBitmap(bitmap);
                            vehicleBookImagePath = saveImage(bitmap);
                            break;
                        case KeyString.VEHICLE_INSURANCE:
                            vehicleInsuranceImage.setImageBitmap(bitmap);
                            vehicleInsurenceImagePath = saveImage(bitmap);
                            break;
                        case KeyString.VEHICLE_FRONT:
                            vehicleFrontImage.setImageBitmap(bitmap);
                            vehicleFrontImagePath = saveImage(bitmap);
                            break;
                        case KeyString.VEHICLE_SIDE_VIEW:
                            vehicleSideViewImage.setImageBitmap(bitmap);
                            vehicleSideImagePath = saveImage(bitmap);
                            break;
                        default:
                            break;
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                    //Toast.makeText(getApplicationContext(), "Failed!", Toast.LENGTH_SHORT).show();
                }
            }

        } else if (requestCode == CAMERA) {
           try {
               //Bitmap bitmap = (Bitmap) data.getExtras().get("data");
               //String path = saveImage(bitmap);
               File file = new File(Environment.getExternalStorageDirectory(), "MyPhoto.jpg");

               //Uri of camera image
               Uri uri = FileProvider.getUriForFile(this, this.getApplicationContext().getPackageName() + ".provider", file);
               Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), uri);
               switch (direction) {
                   case KeyString.VEHICLE_BOOK:
                       vehicleBookImage.setImageBitmap(bitmap);
                       vehicleBookImagePath = saveImage(bitmap);
                       break;
                   case KeyString.VEHICLE_INSURANCE:
                       vehicleInsuranceImage.setImageBitmap(bitmap);
                       vehicleInsurenceImagePath = saveImage(bitmap);
                       break;
                   case KeyString.VEHICLE_FRONT:
                       vehicleFrontImage.setImageBitmap(bitmap);
                       vehicleFrontImagePath = saveImage(bitmap);
                       break;
                   case KeyString.VEHICLE_SIDE_VIEW:
                       vehicleSideViewImage.setImageBitmap(bitmap);
                       vehicleSideImagePath = saveImage(bitmap);
                       break;
                   default:
                       break;
               }
           } catch (Exception e) {

           }
            //Toast.makeText(getApplicationContext(), "Image Saved!", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * reduce selected image size
     * save resized image
     * return resized image file path
     * @param myBitmap
     * @return
     */
    public String saveImage(Bitmap myBitmap) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        ByteArrayOutputStream size = new ByteArrayOutputStream();

        int quality = 100;
        myBitmap.compress(Bitmap.CompressFormat.JPEG, quality, size);

        int imageSizeKB = size.toByteArray().length/1024;
        if (imageSizeKB > 2000) {
            quality = imageSizeKB < 3000 ? 75 : imageSizeKB < 4000 ? 55 : imageSizeKB < 5000 ? 45 :
                    imageSizeKB < 6000 ? 38 : imageSizeKB < 7000 ? 32 :
                            imageSizeKB < 8000 ? 28 : imageSizeKB < 9000 ? 25 :
                                    imageSizeKB < 10000 ? 22 : 15;
            myBitmap.compress(Bitmap.CompressFormat.JPEG, quality, bytes);
        } else {
            myBitmap.compress(Bitmap.CompressFormat.JPEG, quality, bytes);
        }

        File wallpaperDirectory = new File(Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
        // have the object build the directory structure, if needed.
        if (!wallpaperDirectory.exists()) {
            wallpaperDirectory.mkdirs();
        }

        try {
            File f = new File(wallpaperDirectory, Calendar.getInstance().getTimeInMillis() + ".jpg");
            f.createNewFile();
            FileOutputStream fo = new FileOutputStream(f);
            fo.write(bytes.toByteArray());
            MediaScannerConnection.scanFile(this, new String[]{f.getPath()}, new String[]{"image/jpeg"}, null);
            fo.close();
            Log.d("TAG", "File Saved::---&gt;" + f.getAbsolutePath());

            return f.getAbsolutePath();
        } catch (IOException e1) {
            e1.printStackTrace();
        }
        return "";
    }
}
